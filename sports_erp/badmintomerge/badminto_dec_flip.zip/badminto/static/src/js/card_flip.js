odoo.define('badminto.card_flip', function (require) {
    "use strict";
     $(document).ready(function () {
            var cards = document.querySelectorAll('.flip--card');
            var icons = document.querySelectorAll('.set-dashboard__onboarding-card-info');
            if (icons) {
                [...icons].forEach((icon)=>{
                    icon.addEventListener( 'click', function() {
                        var card = icon.closest('.flip--card');
                        if (card){
                            card.classList.toggle('is-flipped');
                        }
                    });
                });
            }
     });
});