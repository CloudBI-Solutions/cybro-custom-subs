from odoo import models, fields


class Users(models.Model):
    """inherit res users"""
    _inherit = "res.users"

    last_name = fields.Char(string='Last Name')
