# -*- coding: utf-8 -*-

from odoo import models, fields


class IrAttachment(models.Model):
    """inherit IrAttachment to add fields for Uploaded videos"""
    _inherit = 'ir.attachment'

    upload_date = fields.Date(string="Upload Date")
    reference = fields.Char(string="Reference")
