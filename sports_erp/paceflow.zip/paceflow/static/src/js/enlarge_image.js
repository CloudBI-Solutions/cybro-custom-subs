odoo.define('paceflow.enlarge_image', function(require){
    "use strict";
    $(document).ready(function(){
        var img_summary_overall_1 = $('#img_summary_overall_1');
        var img_summary_overall_2 = $('#img_summary_overall_2');
        var img_legality = $('#img_legality');
        var img_momentum = $('#img_momentum');
        var img_stability_overall_1 = $('#img_stability_overall_1');
        var img_stability_overall_2 = $('#img_stability_overall_2');
        var img_paceflow_overall_1 = $('#img_paceflow_overall_1');
        var img_paceflow_overall_2 = $('#img_paceflow_overall_2');

        $("#summary_show_image_popup").hide();
        $("#legality_show_image_popup").hide();
        $("#momentum_show_image_popup").hide();
        $("#stability_show_image_popup").hide();
        $("#paceflow_show_image_popup").hide();

        img_summary_overall_1.click(function() {
            $("#summary_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#summary_show_image_popup").fadeIn(200);
                $("#summary_large-image").attr('src',image_path);
            }
        })
        img_summary_overall_2.click(function() {
            $("#summary_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#summary_show_image_popup").fadeIn(200);
                $("#summary_large-image").attr('src',image_path);
            }
        })
        $("#summary_close-btn").click(function(){
            $("#summary_show_image_popup").fadeOut(130);
        })
        img_legality.click(function() {
            $("#legality_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#legality_show_image_popup").fadeIn(200);
                $("#legality_large-image").attr('src',image_path);
            }
        })
        $("#legality_close-btn").click(function(){
            $("#legality_show_image_popup").fadeOut(130);
        })
        img_momentum.click(function() {
            $("#momentum_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#momentum_show_image_popup").fadeIn(200);
                $("#momentum_large-image").attr('src',image_path);
            }
        })
        $("#momentum_close-btn").click(function(){
            $("#momentum_show_image_popup").fadeOut(130);
        })
        img_stability_overall_1.click(function() {
            $("#stability_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#stability_show_image_popup").fadeIn(200);
                $("#stability_large-image").attr('src',image_path);
            }
        })
        img_stability_overall_2.click(function() {
            $("#stability_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#stability_show_image_popup").fadeIn(200);
                $("#stability_large-image").attr('src',image_path);
            }
        })
        $("#stability_close-btn").click(function(){
            $("#stability_show_image_popup").fadeOut(130);
        })
        img_paceflow_overall_1.click(function() {
            $("#paceflow_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#paceflow_show_image_popup").fadeIn(200);
                $("#paceflow_large-image").attr('src',image_path);
            }
        })
        img_paceflow_overall_2.click(function() {
            $("#paceflow_show_image_popup").hide();
            var image_path = $(this).attr('src');
            if (image_path !== '/paceflow/static/description/images/ui/image-thumbnail.png'){
                $("#paceflow_show_image_popup").fadeIn(200);
                $("#paceflow_large-image").attr('src',image_path);
            }
        })
        $("#paceflow_close-btn").click(function(){
            $("#paceflow_show_image_popup").fadeOut(130);
        })
    });
 });