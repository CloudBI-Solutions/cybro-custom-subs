odoo.define('paceflow.multi_select', function(require){
    "use strict";
    $(document).ready(function () {
      $('.paceflow-select').select2();
    });
});