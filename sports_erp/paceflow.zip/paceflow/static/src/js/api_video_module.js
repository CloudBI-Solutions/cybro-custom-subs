odoo.define('paceflow.api_video_module', function(require){
    "use strict";

    var core = require('web.core');
    var FormView = require('web.FormView');
    var FormController = require("web.FormController");
    var rpc = require('web.rpc');

    FormController.include({
    events: {
        'click #assess_button': '_onAssessBtnClick',
        'click #close-overlay': '_onCloseClick',
        },

    _onAssessBtnClick: function (event) {
        var self = this;
        var assessment_id = this.renderer.state.data.id;
        console.log('Assessment', this);
        console.log(self);
         rpc.query({
                    model: 'assessment.assessment',
                    method: 'get_video_urls',
                    args: [[assessment_id]],
                }).then(function (result) {
                    var base_url = window.location.origin;
                    var side_vid = '/web/content/'+result[0]+'?model=ir.attachment';
                    var rear_vid = '/web/content/'+result[1]+'?model=ir.attachment';
                    $('#iframe_id').append('<div id="iframe_div" class="iframe_div"><iframe class="iframe_load" id="videoiframeID" frameBorder="0" src="https://api.analysisfrm.pace-flow.co.uk/analysisTestDev.html"/><img class="close_overlay" id="close-overlay" src="/paceflow/static/description/images/ui/close_backend.png"/></div>');
                    var video = document.getElementById('iframe_id');
                    console.log("video", video)
                    var something = document.getElementById('jpkvpbResultID_0')
                    console.log("something", something)
                })
          },

    _onCloseClick: function (event) {
        const element = document.getElementById("iframe_div");
        element.remove();
        },

    });
});