odoo.define('paceflow.group_data', function(require){
    "use strict";

    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');

    $(document).ready(function(){
        var group_id = $("#groupId").val();
        if (group_id){
            ajax.jsonRpc('/get_group_data', 'call', {'group_id': group_id})
            .then(function (result) {
                var last_session_names = []
                var last_session_score = []
                var color = []
                for (var i = 0; i<result[0].length; i++) {
                    last_session_names.push(result[0][i]['name']);
                    color.push('rgb(59, 33, 93)');
                    last_session_score.push(result[0][i]['last_session_score']);
                }
                last_session_score.push(100)
                last_session_score.push(0)
                var lastSession_ctx = document.getElementById("lastSession").getContext('2d');
                var data_lastSession = {
                    label: "Last Session",
                    labels: last_session_names,
                    datasets: [{
                        barThickness: 2,
                        maxBarThickness: 3,
                        axis: 'y',
                        data: last_session_score,
                        fill: true,
                        backgroundColor: color
                    }]
                };
                var last_session_chart = new Chart(lastSession_ctx, {
                type: "horizontalBar",
                data: data_lastSession,
                options: {
                    scales: {
                       xAxes: [{
                          gridLines: {
                             display: false
                          }
                       }],
                       yAxes: [{
                       barPercentage: 0.7,
                          gridLines: {
                             display: false
                          }
                       }]
                    },
                    legend: {display: false},
                    responsive: true,
                    },
                });

                var last_10_session_names = []
                var last_10_session_score = []

                for (var i = 0; i<result[1].length; i++) {
                    last_10_session_names.push(result[1][i]['name']);
                    last_10_session_score.push(result[1][i]['last_10_assessment_score']);
                }
                last_10_session_score.push(100)
                last_10_session_score.push(0)

                var last_10_session_ctx = document.getElementById("last_10_session").getContext('2d');

                var data_last_10_session = {
                    label: "Last 10 Session",
                    labels: last_10_session_names,
                    datasets: [{
                        barThickness: 6,
                        maxBarThickness: 8,
                        axis: 'y',
                        data: last_10_session_score,
                        fill: true,
                        backgroundColor: color
                    }]
                };

                var last_10_session_chart = new Chart(last_10_session_ctx, {
                type: "horizontalBar",
                data: data_last_10_session,
                options: {
                    scales: {
                       xAxes: [{
                          gridLines: {
                             display: false
                          }
                       }],
                       yAxes: [{
                          barPercentage: 0.7,
                          gridLines: {
                             display: false
                          }
                       }]
                    },
                    legend: {display: false},
                    responsive: true,
                    },
                });

                var top_performers_names = []
                var top_performers_score = []

                for (var i = 0; i<result[2].length; i++) {
                    top_performers_names.push(result[2][i]['name']);
                    top_performers_score.push(result[2][i]['top_performance']);
                }
                top_performers_score.push(100)
                top_performers_score.push(0)
//                console.log(top_performers_names)
//                console.log(top_performers_score)

                var top_performers_ctx = document.getElementById("top_performers").getContext('2d');

                var data_topPerformers = {
                    label: "Top Performers",
                    labels: top_performers_names,
                    datasets: [{
                        barThickness: 6,
                        maxBarThickness: 8,
                        axis: 'y',
                        data: top_performers_score,
                        fill: true,
                        backgroundColor: color,
                        color: 'rgb(59, 33, 93)'
                    }]
                };

                var top_performers_chart = new Chart('top_performers', {
                type: "horizontalBar",
                data: data_topPerformers,
                options: {
                    scales: {
                       xAxes: [{
                          gridLines: {
                             display: false
                          }
                       }],
                       yAxes: [{
                          barPercentage: 0.7,
                          gridLines: {
                             display: false
                          }
                       }]
                    },
                    legend: {display: false},
                    responsive: true,
                    },
                });
            });
        }
    });
});
