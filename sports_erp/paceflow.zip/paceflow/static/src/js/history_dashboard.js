odoo.define('paceflow.history_dashboard', function(require){
    "use strict";
    var publicWidget = require('web.public.widget');
    var core = require('web.core');
    var ajax = require('web.ajax');
    var rpc = require('web.rpc');
    var radarChart = null;
    var mySpeedChart = null;
    var myScoreChart = null;
    var myLegalityChart = null;
    var myRunUpChart = null;
    var myScoreChart = null;
    var myFFCChart = null;
    var myStrideChart = null;

    $(document).ready(function(){
    var assessment_id = $("select[id='h_filter_selection']").val();
    var child_id = $("input[id='h_child_id']").val();
    if(assessment_id){
        rpc.query({
            model: 'assessment.assessment',
            method: 'get_history_dashboard_data',
            args: [assessment_id],
            })
            .then(function (result) {
                var progress_chart = document.getElementById("progress_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;
                var progressData = {
                      labels: x_axis,
                      datasets: [{
                        label: "Score",
                        backgroundColor: "rgba(200,0,0,0.2)",
                        borderColor: "#ff0088",
                        data: y_axis
                      }]
                    };
                    radarChart = new Chart(progress_chart, {
                      type: 'radar',
                      data: progressData,
                      options: {
                            tooltips: {
                                        enabled: true,
                                        callbacks: {
                                            label: function(tooltipItem, data) {
                                                return data.datasets[tooltipItem.datasetIndex].label + ' : ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                                            }
                                        }
                                    },
                            responsive: true, // Instruct chart js to respond nicely.
                            maintainAspectRatio: false,
                            elements: {
                              line: {
                                borderWidth: 3
                              }
                            },
                            scale: {
                            animation: false,
                            ticks: {
                                beginAtZero: true,
                                max: 100,
                                min: 0,
                                stepSize: 10
                            }

                            }
                          },
                    });
            })
        }
        if(child_id){
        rpc.query({
            model: 'assessment.assessment',
            method: 'get_speed_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
                var speed_chart = document.getElementById("speed_canvas").getContext('2d');
                // Define the data
                var speed_x_axis = result.x_axis; // Add data values to array
                var speed_y_axis = result.y_axis;
                mySpeedChart = new Chart(speed_chart, {
                    type: 'line',
                    data: {
                        labels: speed_x_axis,//x axis
                        datasets: [{
                                label: 'Ball-speed', // Name the series
                                data: speed_y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                    }
                });
            })
            rpc.query({
            model: 'assessment.assessment',
            method: 'get_score_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
//                console.log("result", result)
                var score_chart = document.getElementById("score_canvas").getContext('2d');
                // Define the data
                var score_x_axis = result.x_axis; // Add data values to array
                var score_y_axis = result.y_axis;
                myScoreChart = new Chart(score_chart, {
                    type: 'line',
                    data: {
                        labels: score_x_axis,//x axis
                        datasets: [{
                                label: 'Pace-flow Score', // Name the series
                                data: score_y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });
            })
            rpc.query({
            model: 'assessment.assessment',
            method: 'get_legality_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
                var legality_chart = document.getElementById("legality_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;
                myLegalityChart = new Chart(legality_chart, {
                    type: 'line',
                    data: {
                        labels: x_axis,//x axis
                        datasets: [{
                                label: 'Legality', // Name the series
                                data: y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });
            })
            rpc.query({
            model: 'assessment.assessment',
            method: 'get_runup_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
                var runup_chart = document.getElementById("runup_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;
                myRunUpChart = new Chart(runup_chart, {
                    type: 'line',
                    data: {
                        labels: x_axis,//x axis
                        datasets: [{
                                label: 'Momentum', // Name the series
                                data: y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });
            })
            rpc.query({
            model: 'assessment.assessment',
            method: 'get_stride_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
                var stride_chart = document.getElementById("stride_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;
                myStrideChart = new Chart(stride_chart, {
                    type: 'line',
                    data: {
                        labels: x_axis,//x axis
                        datasets: [{
                                label: 'Stability', // Name the series
                                data: y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });
            })
            rpc.query({
            model: 'assessment.assessment',
            method: 'get_ffc_dashboard_data',
            args: [child_id],
            })
            .then(function (result) {
                var ffc_chart = document.getElementById("ffc_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;
                myFFCChart = new Chart(ffc_chart, {
                    type: 'line',
                    data: {
                        labels: x_axis,//x axis
                        datasets: [{
                                label: 'Paceflow', // Name the series
                                data: y_axis, // Specify the data values array
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2, // Specify bar border width
                                type: 'line', // Set this data to a line chart
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });
            })
        }
    });

    publicWidget.registry.websiteProgressDashboardAssessments = publicWidget.Widget.extend({
        selector: '#h_filter',
        events: {
               //tile filter
               'change #h_date_from': '_onChangeDateFilter',
               'change #h_date_to': '_onChangeDateFilter',
               'change #h_filter_selection': '_onChangeFilter',
               'click #h_clear_dates': '_onClickClear',
    },

// CLEAR FUNCTION COMPLETED
    _onClickClear: function (ev) {
         ev.preventDefault();
         var self = this
         var child_id = $("input[id='h_child_id']").val();
         $("input[id='h_date_from']").val(null);
         $("input[id='h_date_to']").val(null);
         ajax.jsonRpc('/get_history_filter_clear_data', 'call', {'child_id': child_id})
             .then(function (result) {
                 $('#h_filter_selection option').remove();
                 for (var i=0; i<result['progress_dashboard'].length; i++){
                     $('#h_filter_selection').append($('<option>',
                     {
                         value: result['progress_dashboard'][i].id,
                         text : result['progress_dashboard'][i].name
                     }));
                 }
             self._onChangeFilter(ev)

             var val_x_axis = result['paceflow_score'].x_axis;
             console.log('val_x', val_x_axis);

             var paceflow_score_chart = document.getElementById("score_canvas").getContext('2d');
             var paceflow_score_y_axis = result['paceflow_score'].y_axis_paceflow_score;

             myScoreChart.destroy();
             myScoreChart = new Chart(paceflow_score_chart, {
                    type: 'line',
                    data: {
                        labels: val_x_axis,
                        datasets: [{
                                label: 'Pace-flow Score',
                                data: paceflow_score_y_axis,
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2,
                                type: 'line',
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });

             var speed_chart = document.getElementById("speed_canvas").getContext('2d');
             var ball_speed_y_axis = result.paceflow_score.y_axis_ball_speed;
             mySpeedChart.destroy();
             mySpeedChart = new Chart(speed_chart, {
                type: 'line',
                data: {
                    labels: val_x_axis,
                    datasets: [{
                            label: 'Ball-speed',
                            data: ball_speed_y_axis,
                            backgroundColor: '#ff0088',
                            borderColor: '#ff0088',

                            borderWidth: 2,
                            type: 'line',
                            fill: false
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                }
             });

                var legality_chart = document.getElementById("legality_canvas").getContext('2d');
                var legality_y_axis = result.paceflow_score.y_axis_legality;
                myLegalityChart.destroy();
                myLegalityChart = new Chart(legality_chart, {
                    type: 'line',
                    data: {
                        labels: val_x_axis,
                        datasets: [{
                                label: 'Legality',
                                data: legality_y_axis,
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2,
                                type: 'line',
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });

                var runup_chart = document.getElementById("runup_canvas").getContext('2d');
                var momentum_y_axis = result.paceflow_score.y_axis_momentum;
                myRunUpChart.destroy();
                myRunUpChart = new Chart(runup_chart, {
                    type: 'line',
                    data: {
                        labels: val_x_axis,
                        datasets: [{
                                label: 'Momentum',
                                data: momentum_y_axis,
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2,
                                type: 'line',
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });

                var stride_chart = document.getElementById("stride_canvas").getContext('2d');
                var momentum_y_axis = result.paceflow_score.y_axis_stability;
                myStrideChart.destroy();
                myStrideChart = new Chart(stride_chart, {
                    type: 'line',
                    data: {
                        labels: val_x_axis,
                        datasets: [{
                                label: 'Stability',
                                data: momentum_y_axis,
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2,
                                type: 'line',
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });

                var ffc_chart = document.getElementById("ffc_canvas").getContext('2d');
                var score_y_axis = result.paceflow_score.y_axis_paceflow;
                myFFCChart.destroy();
                myFFCChart = new Chart(ffc_chart, {
                    type: 'line',
                    data: {
                        labels: val_x_axis,
                        datasets: [{
                                label: 'Paceflow',
                                data: score_y_axis,
                                backgroundColor: '#ff0088',
                                borderColor: '#ff0088',

                                borderWidth: 2,
                                type: 'line',
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            animation: false,
                            yAxes: [{
                                display: true,
                                ticks: {
                                    min: 0,
                                    max: 100
                                }
                            }]
                        }
                    }
                });

            });
         },


// CHANGE DATE COMPLETED
    _onChangeDateFilter: function (ev) {
         ev.preventDefault();
         var self = this
         var child_id = $("input[id='h_child_id']").val();
         var date_from = $("input[id='h_date_from']").val();
         var date_to = $("input[id='h_date_to']").val();
         if(date_to && date_from){
             ajax.jsonRpc('/get_history_filter_data', 'call', {
             'date_from': date_from, 'date_to': date_to, 'child_id': child_id})
             .then(function (result) {
                if (result.progress_dashboard.length == 0){
                    $('#h_filter_selection option').remove();
                    $('#h_filter_selection').append($('<option>',
                     {
                        value: '',
                        text : 'No Assessments in the given date'
                     }));
                     if (radarChart) {
                        radarChart.destroy();
                     }
                     if (myScoreChart){
                        myScoreChart.destroy();
                     }
                     if (mySpeedChart){
                        mySpeedChart.destroy();
                     }
                     if (myLegalityChart){
                        myLegalityChart.destroy();
                     }
                     if (myRunUpChart){
                        myRunUpChart.destroy();
                     }
                     if (myStrideChart){
                        myStrideChart.destroy();
                     }
                     if (myFFCChart){
                        myFFCChart.destroy();
                     }

                    $('#progress_span').attr("aria-hidden", "false");
                    $('#score_span').attr("aria-hidden", "false");
                    $('#speed_span').attr("aria-hidden", "false");
                    $('#legality_span').attr("aria-hidden", "false");
                    $('#momentum_span').attr("aria-hidden", "false");
                    $('#stride_span').attr("aria-hidden", "false");
                    $('#pace_span').attr("aria-hidden", "false");

                }
                else {
                    $('#progress_span').attr("aria-hidden", "true");
                    $('#score_span').attr("aria-hidden", "true");
                    $('#speed_span').attr("aria-hidden", "true");
                    $('#legality_span').attr("aria-hidden", "true");
                    $('#momentum_span').attr("aria-hidden", "true");
                    $('#stride_span').attr("aria-hidden", "true");
                    $('#pace_span').attr("aria-hidden", "true");

                    $('#h_filter_selection option').remove();
                    for (var i=0; i<result.progress_dashboard.length; i++){
                        $('#h_filter_selection').append($('<option>',
                         {
                            value: result.progress_dashboard[i].id,
                            text : result.progress_dashboard[i].name
                         }));
                         }
                    self._onChangeFilter(ev)

                    var score_x_axis = result.paceflow_score.x_axis;

                    var score_chart = document.getElementById("score_canvas").getContext('2d');
                    var score_y_axis = result.paceflow_score.y_axis_score;

                    myScoreChart.destroy();
                    myScoreChart = new Chart(score_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Pace-flow Score',
                                    data: score_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }]},
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                animation: false,
                                yAxes: [{
                                    display: true,
                                    ticks: {
                                        min: 0,
                                        max: 100
                                    }
                                }]
                            }
                        }
                    });

                    var speed_chart = document.getElementById("speed_canvas").getContext('2d');

                    var speed_y_axis = result.paceflow_score.y_axis_speed;

                    mySpeedChart.destroy();
                    mySpeedChart = new Chart(speed_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Ball-speed',
                                    data: speed_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                        }
                    });

                    var legality_chart = document.getElementById("legality_canvas").getContext('2d');

                    var legality_y_axis = result.paceflow_score.y_axis_legality;
                    myLegalityChart.destroy();
                    myLegalityChart = new Chart(legality_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Legality',
                                    data: legality_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                animation: false,
                                yAxes: [{
                                    display: true,
                                    ticks: {
                                        min: 0,
                                        max: 100
                                    }
                                }]
                            }
                        }
                    });

                    var runup_chart = document.getElementById("runup_canvas").getContext('2d');
                    var score_y_axis = result.paceflow_score.y_axis_momentum;
                    myRunUpChart.destroy();
                    myRunUpChart = new Chart(runup_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Momentum',
                                    data: score_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                animation: false,
                                yAxes: [{
                                    display: true,
                                    ticks: {
                                        min: 0,
                                        max: 100
                                    }
                                }]
                            }
                        }
                    });
                    var stride_chart = document.getElementById("stride_canvas").getContext('2d');
                    var score_y_axis = result.paceflow_score.y_axis_stability;
                    myStrideChart.destroy();
                    myStrideChart = new Chart(stride_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Stability',
                                    data: score_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                animation: false,
                                yAxes: [{
                                    display: true,
                                    ticks: {
                                        min: 0,
                                        max: 100
                                    }
                                }]
                            }
                        }
                    });

                    var ffc_chart = document.getElementById("ffc_canvas").getContext('2d');
                    var score_y_axis = result.paceflow_score.y_axis_paceflow;
                    myFFCChart.destroy();
                    myFFCChart = new Chart(ffc_chart, {
                        type: 'line',
                        data: {
                            labels: score_x_axis,
                            datasets: [{
                                    label: 'Paceflow',
                                    data: score_y_axis,
                                    backgroundColor: '#ff0088',
                                    borderColor: '#ff0088',

                                    borderWidth: 2,
                                    type: 'line',
                                    fill: false
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                animation: false,
                                yAxes: [{
                                    display: true,
                                    ticks: {
                                        min: 0,
                                        max: 100
                                        }
                                }]
                            }
                        }
                    });
                    }
            });
        }
    },

//CHANGE
    _onChangeFilter: function (ev) {
         ev.preventDefault();
         var loader = 0;
         var assessment_id = $("select[id='h_filter_selection']").val();
         rpc.query({
            model: 'assessment.assessment',
            method: 'get_history_dashboard_data',
            args: [assessment_id],
            })
            .then(function (result) {
                console.log("resulllt", result)
                var progress_chart = document.getElementById("progress_canvas").getContext('2d');
                // Define the data
                var x_axis = result.x_axis; // Add data values to array
                var y_axis = result.y_axis;

                var progressData = {
                      labels: x_axis,
                      datasets: [{
                        label: "Score",
                        backgroundColor: "rgba(200,0,0,0.2)",
                        borderColor: "#ff0088",
                        data: y_axis
                      }]
                    };
                    radarChart.destroy();
                    radarChart = new Chart(progress_chart, {
                      type: 'radar',
                      data: progressData,
                      options: {
                          animation: {
                                onProgress: function(animation) {
                                    if (loader == 0){
                                        var loading_anime = document.querySelector(
                                          "#loader")
                                        loading_anime.style.display = "flex";
                                        loader = 1;
                                        }
                                    },
                                onComplete: function(context) {
                                    var loading_anime = document.querySelector(
                                          "#loader")
                                        loading_anime.style.display = "none";
                                }
                            },
                            tooltips: {
                                        enabled: true,
                                        callbacks: {
                                            label: function(tooltipItem, data) {
                                                return data.datasets[tooltipItem.datasetIndex].label + ' : ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                                            }
                                        }
                                    },
                            responsive: true,
                            maintainAspectRatio: false,
                            elements: {
                              line: {
                                borderWidth: 3
                              }
                            },
                            scale: {
                            animation: false,
                            ticks: {
                                beginAtZero: true,
                                max: 100,
                                min: 0,
                                stepSize: 10
                            }

                            }
                          },
                    });
                })

            },
    });
});