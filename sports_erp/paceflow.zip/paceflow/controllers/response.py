import base64
import json

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class VideoProcessing(http.Controller):

    @http.route('/video/processing', type='http', auth='public', csrf=False,
                method=['POST'])
    def video_processing(self, **post):
        print("kw", post)
        # momentum_overall = post.get('momentum_overall')
        # print('img', momentum_overall['img_momentum_overall'])

        # assessment = request.env['assessment.assessment'].sudo().browse(
        #     int(request.jsonrequest.get('id')))
        # print("oooo", assessment.img_cadence_efficiency)
        # image = request.jsonrequest.get('img_momentum_overall').split(",")
        # print('imgg', image)
        # assessment.write({
            # 'img_cadence_tempo': new_image
        # })
        # print('assess', assessment)
        # print(request.jsonrequest)
        # assessment.write({
        #     'test_html': json.dumps(request.jsonrequest)
        # })
        return True
