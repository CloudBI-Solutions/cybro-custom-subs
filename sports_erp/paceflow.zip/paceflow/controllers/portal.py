import base64

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class WebsiteSalePaceflowClient(WebsiteSale):
    @http.route(['/shop/confirmation'],
                type='http', auth="public", website=True)
    def payment_confirmation(self, **post):
        response = super(WebsiteSalePaceflowClient,
                         self).shop_payment_confirmation(**post)
        order_lines = response.qcontext['order'].order_line
        if request.env.context.get('uid'):
            paceflow_product = request.env['product.product'].sudo().browse(
                               request.env.ref('paceflow.paceflow_package').id)
            for line in order_lines:
                if line.product_id == paceflow_product:
                    partner = request.env.user.partner_id
                    client = request.env['paceflow.client'].sudo().search(
                        [('partner_id', '=', partner.id)])
                    partner.sudo().write({
                        'is_client': True,
                    })
                    if not client:
                        request.env['paceflow.client'].sudo().create({
                                'partner_id': partner.id,
                            })
            return response


class Portal(CustomerPortal):

    @route(['/my', '/my/home'], type='http', auth="user", website=True)
    def home(self, **kw):
        """HOME DASHBOARD RENDER"""
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        client = request.env['paceflow.client'].sudo().search(
                [('partner_id', '=', partner.id)])
        if request.env.user.has_group('paceflow.group_paceflow_coaches'):
            if not client:
                request.env['paceflow.client'].sudo().create({
                    'partner_id': partner.id,
                })
            partner.is_client = True
        else:
            if not partner.is_client and not partner.is_parent and not partner.is_child:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        if partner.is_client:
            params = request.env['ir.config_parameter'].sudo()
            mobile = params.get_param('paceflow.mobile')
            tablet = params.get_param('paceflow.tablet')
            desktop = params.get_param('paceflow.desktop')
            values.update({
                'mobile': mobile,
                'tablet': tablet,
                'desktop': desktop,
            })
            if client:
                child_contacts = client.child_ids
                values.update({
                    'child_contacts': child_contacts,
                })
            else:
                values.update({
                    'child_contacts': '',
                })
            response = request.render("paceflow.paceflow_portal_my_home",
                                      values)
            return response
        else:
            if partner.is_parent:
                values.update({
                    'partner': partner,
                })
            if partner.is_child:
                child = request.env['paceflow.child'].search(
                    [('partner_id', '=', partner.id)])
                values.update({
                    'partner': partner,
                    'child': child,
                })
        return request.render("portal.portal_my_home", values)

    @route(['/my/upload'], type='http', auth='user', website=True)
    def upload_form(self, **kw):
        """UPLOAD VIDEO REAR PAGE LOAD"""
        if not kw:
            return request.redirect("/my/")
        else:
            child_id = request.env['paceflow.child'].sudo().browse(
                int(kw.get('child_id')))
            values = {}
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search(
                [('partner_id', '=', partner.id)])
            child_contacts = client.child_ids
            values.update({
                'child_id': child_id,
                'partner': partner,
                'child_contacts': child_contacts,
            })
            response = request.render("paceflow.upload_rear_video_form",
                                      values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/video_submit'], type='http', auth='user', website=True)
    def rear_video_submit(self, **post):
        """REAR VIDEO SUBMIT WITH SIDE VIDEO PAGE RENDER"""
        if not post:
            return request.redirect("/my/")
        else:
            partner = request.env.user.partner_id
            coach = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                                int(post['upload_child_id']))
            assessment = request.env[
                'assessment.assessment'].sudo().create({
                        'partner_id': coach.id,
                        'child_id': child.id,
                        'highest_standard': child.highest_standard,
                        'hand': child.partner_id.hand,
                        'dob': child.dob,
                        'report_date': post.get('assessment_date'),
                        'name': '%s %s - %s' % (child.partner_id.name,
                                                child.partner_id.last_name,
                                                post.get('assessment_date'))})
            attachments = request.env['ir.attachment']
            if post.get('attachment_rear'):
                attachment_rear = attachments.sudo().create({
                    'name': post.get('attachment_rear').filename,
                    'type': 'binary',
                    'datas': base64.b64encode(post.get(
                        'attachment_rear').read()),
                    'res_model': assessment._name,
                    'res_id': assessment.id,
                    'reference': post.get('reference'),
                    'upload_date': post.get('date'),
                })
                assessment.sudo().write({
                    'attachment_ids': [(4, attachment_rear.id)],
                    'rear_video': attachment_rear.datas,
                    'rear_reference': post.get('reference')
                })
            elif post.get('record_rear'):
                attachment_rear = attachments.sudo().create({
                    'name': post.get('record_rear').filename,
                    'type': 'binary',
                    'datas': base64.b64encode(
                        post.get('record_rear').read()),
                    'res_model': assessment._name,
                    'res_id': assessment.id,
                    'reference': post.get('reference'),
                    'upload_date': post.get('date'),
                })
                assessment.sudo().write({
                    'attachment_ids': [(4, attachment_rear.id)],
                    'rear_video': attachment_rear.datas,
                    'rear_reference': post.get('reference')
                })
            values = {}
            if assessment:
                values.update({
                    'child_id': child,
                    'assessment_id': assessment
                })
                response = request.render(
                    "paceflow.upload_side_video_form", values)
            else:
                response = request.render(
                    "paceflow.portal_upload_error_page")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/upload_complete'], type='http', auth='user', website=True)
    def side_video_submit(self, **post):
        """SIDE VIDEO SUBMIT"""
        if post:
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(post.get('assessment_id_video')))
            attachments = request.env['ir.attachment']
            if post.get('attachment_side'):
                attachment_side = attachments.sudo().create({
                    'name': post.get('attachment_side').filename,
                    'type': 'binary',
                    'datas': base64.b64encode(
                        post.get('attachment_side').read()),
                    'res_model': assessment._name,
                    'res_id': assessment.id,
                    'reference': post.get('reference'),
                    'upload_date': post.get('date'),
                })
                assessment.sudo().write({
                    'attachment_ids': [(4, attachment_side.id)],
                    'side_video': attachment_side.datas,
                    'side_reference': post.get('reference'),
                })
            elif post.get('record_side'):
                attachment_side = attachments.sudo().create({
                    'name': post.get('record_side').filename,
                    'type': 'binary',
                    'datas': base64.b64encode(
                        post.get('record_side').read()),
                    'res_model': assessment._name,
                    'res_id': assessment.id,
                    'reference': post.get('reference'),
                    'upload_date': post.get('date'),
                })
                assessment.sudo().write({
                    'attachment_ids': [(4, attachment_side.id)],
                    'side_video': attachment_side.datas,
                    'side_reference': post.get('reference'),
                })
            if assessment:
                response = request.render(
                    "paceflow.portal_upload_thanks_page")
            else:
                response = request.render("paceflow.portal_upload_error_page")

            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/profile'], type='http', auth='user', website=True)
    def profile(self):
        """PROFILE PAGE"""
        values = {}
        partner = request.env.user.partner_id
        countries = request.env['res.country'].sudo().search([])
        states = request.env['res.country.state'].sudo().search([])
        values.update({
            'partner': partner,
            'states': states,
            'countries': countries, })
        if partner.phone:
            code = partner.phone.split(" ")
            if len(code) > 1:
                values.update({
                    'country_code': code[0],
                    'number': code[1],
                })
            else:
                values.update({
                    'country_code': '',
                    'number': code[0],
                })
        else:
            values.update({
                'country_code': '',
                'number': '',
            })
        if partner.is_child:
            child = request.env['paceflow.child'].sudo().search([
                ('partner_id', '=', partner.id)
            ])
            values.update({
                'child_view': True,
                'child_groups': child.group_ids,
                'child_parents': child.parent_ids,
            })
        else:
            values.update({
                'child_view': False,
            })
        response = request.render("paceflow.my_profile", values)
        response.headers['X-Frame-Options'] = 'DENY'
        return response

    @route(['/my/update_profile'], type='http', auth='user', website=True)
    def update_profile(self, **post):
        """UPDATE PROFILE"""
        partner = request.env['res.partner'].sudo().browse(
                                        int(post['partner']))
        partner_name = post.get('partner_name').rpartition(" ")
        partner_first = partner_name[0]
        partner_last = partner_name[-1]
        if not partner_first:
            partner_first = partner_name[-1]
            partner_last = ''
        values = {
            'name': partner_first,
            'last_name': partner_last,
            'email': post.get('email'),
            'phone': post.get('code') + ' ' + post.get('phone'),
            'street': post.get('house'),
            'street2': post.get('street'),
            'city': post.get('town'),
            'state_id': int(post.get('state_id')),
            'zip': post.get('phonecode'),
            'country_id': int(post.get('country_id')), }
        if post.get('photo'):
            values.update({
                'image_1920': base64.b64encode(post.get('photo').read())
            })
        elif not post.get('photo') and int(post.get('remove_photo')) == 1:
            values.update({
                'image_1920': '',
            })
        partner.sudo().write(values)
        return request.redirect("/my/profile")

    @route(['/my/history_dashboard/<int:child_id>',
            '/history_dashboard/<int:child_id>'], type='http', auth='user',
           website=True)
    def history_dashboard(self, child_id=None):
        """HISTORY DASHBOARD"""
        if request.env.user.partner_id.is_client:
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            stage = request.env['assessment.stage'].sudo().browse(
                    request.env.ref('paceflow.stage_done').id)
            assessments = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=10)

            highest_ball_speed = 0.0
            highest_paceflow_score = 0.0

            for assess in assessments:
                if assess.velocity > highest_ball_speed:
                    highest_ball_speed = assess.velocity
                if assess.summary_overall_score > highest_paceflow_score:
                    highest_paceflow_score = round(assess.summary_overall_score)

            assessment = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=1)
            values.update({
                'child': child,
                'assessment': assessment,
                'assessments': assessments,
                'ball_speed': highest_ball_speed,
                'summary_dashboard_data':
                    highest_paceflow_score,
            })
            response = request.render(
                "paceflow.portal_history_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            partner = request.env.user.partner_id
            parent = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            parent_children = parent.child_ids
            if child.id not in parent_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            stage = request.env['assessment.stage'].sudo().browse(
                request.env.ref('paceflow.stage_done').id)
            assessments = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=10)

            highest_ball_speed = 0.0
            highest_paceflow_score = 0.0

            for assess in assessments:
                if assess.velocity > highest_ball_speed:
                    highest_ball_speed = assess.velocity
                if assess.summary_overall_score > highest_paceflow_score:
                    highest_paceflow_score = round(assess.summary_overall_score)

            assessment = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=1)
            values.update({
                'child': child,
                'assessment': assessment,
                'assessments': assessments,
                'ball_speed': highest_ball_speed,
                'summary_dashboard_data': highest_paceflow_score,
            })
            response = request.render(
                "paceflow.portal_history_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            partner_id = request.env.user.partner_id
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            child_partner = child.partner_id
            if partner_id == child_partner:
                values = {}
                stage = request.env['assessment.stage'].sudo().browse(
                    request.env.ref('paceflow.stage_done').id)
                assessments = request.env[
                    'assessment.assessment'].sudo().search(
                    [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                    order='create_date desc', limit=10)

                highest_ball_speed = 0.0
                highest_paceflow_score = 0.0

                for assess in assessments:
                    if assess.velocity > highest_ball_speed:
                        highest_ball_speed = assess.velocity
                    if assess.summary_overall_score > highest_paceflow_score:
                        highest_paceflow_score = round(
                            assess.summary_overall_score)
                assessment = request.env['assessment.assessment'].sudo().search(
                    [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                    order='create_date desc', limit=1)
                values.update({
                    'child': child,
                    'assessment': assessment,
                    'assessments': assessments,
                    'ball_speed': highest_ball_speed,
                    'summary_dashboard_data': highest_paceflow_score,
                })
                response = request.render(
                    "paceflow.portal_history_dashboard", values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response

            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/assessment_report/<int:child_id>',
            '/assessment_report/<int:child_id>'],
           type='http', auth='user', website=True)
    def assessment_report(self, child_id=None):
        """CHILD ASSESSMENT REPORT"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            child_partner = child.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            stage = request.env['assessment.stage'].sudo().browse(
                request.env.ref('paceflow.stage_done').id)
            assessments = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc')
            assessment = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=1)
            values.update({
                'partner': partner,
                'child': child,
                'child_partner': child_partner,
                'assessments': assessments,
                'assessment': assessment,
                'img_summary1': assessment.img_summary_overall_1,
                'img_summary2': assessment.img_summary_overall_2,
            })
            response = request.render("paceflow.portal_client_dashboard",
                                      values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].search([
                ('partner_id', '=', parent_partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            child_partner = child.partner_id
            values = {}
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            stage = request.env['assessment.stage'].sudo().browse(
                request.env.ref('paceflow.stage_done').id)
            assessments = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc')
            assessment = request.env['assessment.assessment'].sudo().search(
                [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                order='create_date desc', limit=1)
            values.update({
                'partner': parent_partner,
                'child': child,
                'child_partner': child_partner,
                'assessments': assessments,
                'assessment': assessment,
                'img_summary1': assessment.img_summary_overall_1,
                'img_summary2': assessment.img_summary_overall_2,
            })
            response = request.render("paceflow.portal_client_dashboard",
                                                                    values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            partner_id = request.env.user.partner_id
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            child_partner = child.partner_id
            if partner_id == child_partner:
                values = {}
                stage = request.env['assessment.stage'].sudo().browse(
                    request.env.ref('paceflow.stage_done').id)
                assessments = request.env['assessment.assessment'].sudo().search(
                    [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                    order='create_date desc')
                assessment = request.env['assessment.assessment'].sudo().search(
                    [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
                    order='create_date desc', limit=1)
                values.update({
                    'partner': child_partner,
                    'child': child,
                    'child_partner': child_partner,
                    'assessments': assessments,
                    'assessment': assessment,
                    'img_summary1': assessment.img_summary_overall_1,
                    'img_summary2': assessment.img_summary_overall_2,
                })
                response = request.render("paceflow.portal_client_dashboard",
                                          values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/assessment_report/<int:child_id>/legality/<int:assessment_id>',
            '/child_details/<int:child_id>/legality/<int:assessment_id>'],
           type='http', auth='user', website=True)
    def legality(self, **kwargs):
        """LEGALITY PAGE RENDER"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                                                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.legality_note_ids:
                values.update({
                    'legality_comments': assessment.legality_note_ids
                })
            response = request.render("paceflow.legality_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].search([
                ('partner_id', '=', parent_partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.legality_note_ids:
                values.update({
                    'legality_comments': assessment.legality_note_ids
                })
            response = request.render("paceflow.legality_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            child = request.env['paceflow.child'].sudo().browse(
                                    int(kwargs['child_id']))
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            if assessment.child_id == child:
                values = {}
                values.update({
                    'child': child,
                    'assessment': assessment,
                })
                if assessment.legality_note_ids:
                    values.update({
                        'legality_comments': assessment.legality_note_ids
                    })
                response = request.render("paceflow.legality_dashboard", values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route([
        '/my/assessment_report/<int:child_id>/stability/<int:assessment_id>',
        '/child_details/<int:child_id>/stability/<int:assessment_id>'],
           type='http', auth='user', website=True)
    def stability(self, **kwargs):
        """STABILITY PAGE RENDER"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.stability_note_ids:
                values.update({
                    'stability_comments': assessment.stability_note_ids
                })
            response = request.render("paceflow.stability_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].search([
                ('partner_id', '=', parent_partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.stability_note_ids:
                values.update({
                    'stability_comments': assessment.stability_note_ids
                })
            response = request.render("paceflow.stability_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            child = request.env['paceflow.child'].sudo().browse(
                                    int(kwargs['child_id']))
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            if assessment.child_id == child:
                values = {}
                values.update({
                    'child': child,
                    'assessment': assessment,
                })
                if assessment.stability_note_ids:
                    values.update({
                        'stability_comments': assessment.stability_note_ids
                    })
                response = request.render("paceflow.stability_dashboard", values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/assessment_report/<int:child_id>/momentum/<int:assessment_id>',
            '/child_details/<int:child_id>/momentum/<int:assessment_id>'],
           type='http', auth='user', website=True)
    def momentum(self, **kwargs):
        """RENDER MOMENTUM PAGE"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.momentum_note_ids:
                values.update({
                    'momentum_comments': assessment.momentum_note_ids
                })
            response = request.render("paceflow.momentum_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].search([
                ('partner_id', '=', parent_partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.momentum_note_ids:
                values.update({
                    'momentum_comments': assessment.momentum_note_ids
                })
            response = request.render("paceflow.momentum_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            if assessment.child_id == child:
                values = {}
                values.update({
                    'child': child,
                    'assessment': assessment,
                })
                if assessment.momentum_note_ids:
                    values.update({
                        'momentum_comments': assessment.momentum_note_ids
                    })
                response = request.render("paceflow.momentum_dashboard",
                                          values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/assessment_report/<int:child_id>/paceflow/<int:assessment_id>',
            '/child_details/<int:child_id>/paceflow/<int:assessment_id>'],
           type='http', auth='user', website=True)
    def pacelfow(self, **kwargs):
        """PACEFLOW PAGE RENDER"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.paceflow_note_ids:
                values.update({
                    'paceflow_comments': assessment.paceflow_note_ids
                })
            response = request.render("paceflow.paceflow_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].search([
                ('partner_id', '=', parent_partner.id)])
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            values.update({
                'child': child,
                'assessment': assessment,
            })
            if assessment.paceflow_note_ids:
                values.update({
                    'paceflow_comments': assessment.paceflow_note_ids
                })
            response = request.render("paceflow.paceflow_dashboard", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_child:
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            assessment = request.env['assessment.assessment'].sudo().browse(
                int(kwargs['assessment_id']))
            if assessment.child_id == child:
                values = {}
                values.update({
                    'child': child,
                    'assessment': assessment,
                })
                if assessment.paceflow_note_ids:
                    values.update({
                        'paceflow_comments': assessment.paceflow_note_ids
                    })
                response = request.render("paceflow.paceflow_dashboard",
                                          values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/edit_child/<int:child_id>'], type='http', auth='user', website=True)
    def edit_child(self, **kwargs):
        """CHILD EDIT PAGE RENDER"""
        if request.env.user.partner_id.is_client:
            values = {}
            child = request.env['paceflow.child'].sudo().browse(
                                            int(kwargs['child_id']))
            partner = request.env.user.partner_id
            child_partner = child.partner_id
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values.update({
                'partner': partner,
                'child_partner': child_partner,
                'child': child,
            })
            code = child.phone.split(" ")
            if len(code) > 1:
                values.update({
                    'country_code': code[0],
                    'number': code[1],
                })
            else:
                values.update({
                    'country_code': '',
                    'number': code[0],
                })
            child_group_ids = child.group_ids
            groups = request.env['paceflow.child.group'].sudo().search([
                ('id', 'not in', child_group_ids.ids),
                ('responsible_user', '=', client.id)])
            child_parent_ids = child.parent_ids
            parents = request.env['paceflow.parents'].sudo().search([
                ('created_coach', '=', client.id),
                ('id', 'not in', child_parent_ids.ids)
            ])
            values.update({
                'child_groups': child_group_ids,
                'groups': groups,
                'child_parents': child_parent_ids,
                'parents': parents,
                'client_view': True,
                'parent_view': False
            })
            response = request.render(
                "paceflow.child_edit_form_template", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response

        elif request.env.user.partner_id.is_parent:
            values = {}
            child = request.env['paceflow.child'].sudo().browse(
                int(kwargs['child_id']))
            child_partner = child.partner_id
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].sudo().search([
                ('partner_id', '=', parent_partner.id)
            ])
            if child.id not in parent.child_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values.update({
                'partner': parent_partner,
                'child_partner': child_partner,
                'child': child,
            })
            code = child.phone.split(" ")
            if len(code) > 1:
                values.update({
                    'country_code': code[0],
                    'number': code[1],
                })
            else:
                values.update({
                    'country_code': '',
                    'number': code[0],
                })
            child_group_ids = child.group_ids
            groups = []
            values.update({
                'child_groups': child_group_ids,
                'groups': groups,
                'client_view': False,
                'parent_view': True
            })
            response = request.render(
                "paceflow.child_edit_form_template", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/group'], type='http', auth='user', website=True)
    def my_group(self):
        """GROUP HOME PAGE"""
        if request.env.user.partner_id.is_client:
            values = {}
            coach = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            groups = request.env['paceflow.child.group'].sudo().search([
                ('responsible_user', '=', coach.id)])
            values.update({
                'groups': groups,
            })
            response = request.render("paceflow.group_home", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/create_group'], type='http', auth='user', website=True)
    def group_create(self):
        """GROUP CREATE TEMPLATE"""
        if request.env.user.partner_id.is_client:
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            children = request.env['paceflow.child'].sudo().search([])
            players = children.filtered(lambda r: coach_id in r.coach_ids)
            response = request.render("paceflow.group_create",
                                      {'players': players})
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/submit_group'], type='http', auth='user', website=True)
    def group_submit(self, **post):
        """GROUP CREATE SUBMIT"""
        child_ids = list(map(int, request.httprequest.form.getlist('childs')))
        coach = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', request.env.user.partner_id.id)
        ])
        group = request.env['paceflow.child.group'].sudo().create({
            'name': post.get('group-name'),
            'description': post.get('group-description'),
            'responsible_user': coach.id
        })
        if post.get('photo'):
            group.write({
                'image_1920': base64.b64encode(post.get('photo').read()),
            })
        if child_ids:
            for child_id in child_ids:
                group.write({
                    'child_ids': [(4, child_id)]
                })
                request.env['paceflow.child'].browse(child_id).sudo().write({
                    'group_ids': [(4, group.id)]
                })
        coach.sudo().write({
            'group_ids': [(4, group.id)]
        })
        return request.redirect("/my/group")

    @route(['/my/group_details/<int:group_id>'], type='http',
           auth='user', website=True)
    def group_details(self, **kwargs):
        """GROUP DETAILS TEMPLATE"""
        if request.env.user.partner_id.is_client:
            group = request.env['paceflow.child.group'].sudo().browse(
                int(kwargs.get('group_id')))
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            if group.id not in coach_id.group_ids.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            values = {}
            values.update({
                'group': group})
            group_players = group.child_ids
            values.update({
                'group_players': group_players,
            })
            response = request.render("paceflow.group_view", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/group_edit/<int:group_id>'], type='http',
           auth='user', website=True)
    def group_edit(self, **kwargs):
        """EDIT GROUP TEMPLATE"""
        if request.env.user.partner_id.is_client:
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            group = request.env['paceflow.child.group'].sudo().browse(
                int(kwargs.get('group_id')))
            values = {}
            values.update({
                'group': group})
            group_players = group.child_ids
            children = request.env['paceflow.child'].sudo().search([])
            players = children.filtered(lambda r: coach_id in r.coach_ids)
            values.update({
                'group_players': group_players,
                'players': players
            })
            response = request.render("paceflow.group_edit", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/update_group'], type='http', auth='user', website=True)
    def group_update(self, **post):
        """UPDATE GROUP SUBMIT"""
        group = request.env['paceflow.child.group'].sudo().browse(
                                                        int(post.get('id')))
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', request.env.user.partner_id.id)])
        child_ids = list(map(int, request.httprequest.form.getlist('childs')))
        group.sudo().write({
            'name': post.get('group_name'),
            'description': post.get('description'),
        })
        group.sudo().write({
            'child_ids': [(5, 0, 0)]
        })
        children = request.env['paceflow.child'].sudo().search([])
        childs = children.filtered(lambda r: coach_id in r.coach_ids)
        for child in childs:
            for rec in child.group_ids:
                if rec.id == group.id:
                    child.sudo().write({
                        'group_ids': [(3, group.id)]
                    })
        if post.get('photo'):
            group.sudo().write({
                'image_1920': base64.b64encode(post.get('photo').read()),
            })
        elif not post.get('photo') and int(post.get('remove_photo')) == 1:
            group.sudo().write({
                'image_1920': '',
            })
        if child_ids:
            for child_id in child_ids:
                group.sudo().write({
                    'child_ids': [(4, child_id)]
                })
                request.env['paceflow.child'].browse(child_id).sudo().write({
                    'group_ids': [(4, group.id)]
                })
        return request.redirect("/my/group_details/%s" % group.id)

    @route(['/my/parent_home'], type='http', auth='user', website=True)
    def parent_home(self):
        """PARENT HOME TEMPLATE"""
        if request.env.user.partner_id.is_client:
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            parents = request.env['paceflow.parents'].sudo().search([
                ('created_coach', '=', coach_id.id)])
            response = request.render("paceflow.parent_home",
                                      {'parent_contacts': parents})
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/create_parent'], type='http', auth='user', website=True)
    def create_parent(self):
        """CREATE NEW PARENT TEMPLATE"""
        if request.env.user.partner_id.is_client:
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            children = request.env['paceflow.child'].sudo().search([])
            childs = children.filtered(lambda r: coach_id in r.coach_ids)
            response = request.render("paceflow.parent_create",
                                      {'childs': childs})
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/submit_parent'], type='http', auth='user', website=True)
    def submit_parent(self, **post):
        """SUBMIT CREATED PARENT"""
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', request.env.user.partner_id.id)])
        child_ids = list(map(int, request.httprequest.form.getlist('childs')))
        parent_partner = request.env['res.partner'].sudo().create({
            'name': post.get('firstname'),
            'last_name': post.get('lastname'),
            'email': post.get('email'),
            'phone': post.get('tele_code') + ' ' + post.get('telephone')
            })
        parent = request.env['paceflow.parents'].sudo().create({
            'partner_id': parent_partner.id,
            'email': post.get('email'),
            'phone': post.get('tele_code') + ' ' + post.get('telephone'),
            'created_coach': coach_id.id,
            'emergency_number': post.get('emer_code') + ' ' + post.get(
                'emergency')
        })
        parent_user = request.env['res.users'].sudo().create({
            'name': post.get('firstname'),
            'last_name': post.get('lastname'),
            'login': post.get('email'),
            'partner_id': parent_partner.id,
            'sel_groups_1_9_10': 9,
        })
        if post['photo']:
            parent_partner.sudo().write({
                'image_1920': base64.b64encode(post.get('photo').read()),
            })
        if child_ids:
            for child_id in child_ids:
                parent.sudo().write({
                    'child_ids': [(4, child_id)]})
                request.env['paceflow.child'].browse(child_id).sudo().write({
                    'parent_ids': [(4, parent.id)]
                })
        parent.partner_id.sudo().write({
            'is_parent': True,
        })
        return request.redirect("/my/parent_home")

    @route(['/my/parent_details/<int:parent_id>'], type='http',
           auth='user', website=True)
    def parent_details(self, **kwargs):
        """PARENT DETAILS TEMPLATE"""
        if request.env.user.partner_id.is_client:
            values = {}
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)])
            parent = request.env['paceflow.parents'].sudo().browse(
                                                int(kwargs.get('parent_id')))
            if parent.created_coach == coach_id:
                parent_child_ids = parent.child_ids
                children = request.env['paceflow.child'].sudo().search([])
                child_ids = children.filtered(
                    lambda r: (coach_id in r.coach_ids))
                tele = parent.phone.split(" ")
                emer = parent.emergency_number.split(" ")
                values.update({
                    'parent': parent,
                    'tele_code': tele[0],
                    'phone': tele[1],
                    'emer_code': emer[0],
                    'emergency': emer[1],
                    'parent_child': parent_child_ids,
                    'child_ids': child_ids
                })
                response = request.render("paceflow.parent_details", values)
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/update_parent_details'], type='http',
           auth='user', website=True)
    def update_parent_details(self, **post):
        """UPDATE PARENT DETAILS"""
        child_ids = list(map(int, request.httprequest.form.getlist('childs')))
        parent = request.env['paceflow.parents'].sudo().browse(
            int(post.get('id')))
        parent_partner = parent.partner_id
        parent_user = request.env['res.users'].sudo().search([
            ('partner_id', '=', parent_partner.id)
        ])
        parent_partner.sudo().write({
            'name': post.get('name'),
            'last_name': post.get('lastname'),
            'phone': post.get('tele_code') + ' ' + post.get('phone'),
            'email': post.get('email')
        })
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', request.env.user.partner_id.id)
        ])
        parent.sudo().write({
            'child_ids': [(5, 0, 0)]})
        children = request.env['paceflow.child'].sudo().search([])
        childs = children.filtered(lambda r: coach_id in r.coach_ids)
        for child in childs:
            for rec in child.parent_ids:
                if rec.id == parent.id:
                    child.sudo().write({
                        'parent_ids': [(3, parent.id)]
                    })
        parent_user.sudo().write({
            'name': post.get('name'),
            'last_name': post.get('lastname'),
            'login': post.get('email'),
        })
        parent.sudo().write({
            'email': post.get('email'),
            'phone': post.get('tele_code') + ' ' + post.get('phone'),
            'emergency_number': post.get('emer_code') + ' ' + post.get(
                'emergency')
        })
        if post['photo']:
            parent_partner.write({
                'image_1920': base64.b64encode(post.get('photo').read()),
            })
        elif not post.get('photo') and int(post.get('remove_photo')) == 1:
            parent_partner.write({
                'image_1920': '',
            })
        if child_ids:
            for child_id in child_ids:
                parent.sudo().write({
                    'child_ids': [(4, child_id)]})
                request.env['paceflow.child'].browse(child_id).sudo().write({
                    'parent_ids': [(4, parent.id)]
                })
        return request.redirect("/my/parent_home")

    @route(['/my/submit_details'], type='http', auth='user', website=True)
    def submit_details(self, **post):
        """UPDATE CHILD DETAILS"""
        if request.env.user.partner_id.is_client:
            child = request.env['paceflow.child'].sudo().browse(
                                int(post['child_id']))
            group_ids = list(map(
                int, request.httprequest.form.getlist('groups')))
            parent_ids = list(map(
                int, request.httprequest.form.getlist('parents')))
            child_partner = child.partner_id
            child_partner.write({
                'name': post['name'],
                'last_name': post['lastname'],
                'email': post['email'],
                'phone': post['code'] + ' ' + post['phone'],
                'hand': post.get('hand')
            })
            child_user = request.env['res.users'].sudo().search([
                ('partner_id', '=', child_partner.id)
            ])
            if post['photo']:
                child_partner.sudo().write({
                    'image_1920': base64.b64encode(post.get('photo').read()),
                })
            elif not post.get('photo') and int(post.get('remove_photo')) == 1:
                child_partner.sudo().write({
                    'image_1920': '',
                })
            child.sudo().write({
                'dob': post['dob'],
                'phone': post['code'] + ' ' + post['phone'],
                'email': post['email'],
                'highest_standard': post['highestStd'],
            })
            child_user.sudo().write({
                'name': post.get('name'),
                'last_name': post.get('lastname'),
                'login': post.get('email'),
            })
            child.sudo().write({
                'group_ids': [(5, 0, 0)],
                'parent_ids': [(5, 0, 0)]
            })
            groups = request.env['paceflow.child.group'].sudo().search([])
            group = groups.filtered(lambda r: child in r.child_ids)
            for rec in group:
                rec.sudo().write({
                    'child_ids': [(3, child.id)]
                })
            parents = request.env['paceflow.parents'].sudo().search([])
            parent = parents.filtered(lambda r: child in r.child_ids)
            for rec in parent:
                rec.sudo().write({
                    'child_ids': [(3, child.id)]
                })
            if group_ids:
                for group_id in group_ids:
                    child.sudo().write({
                        'group_ids': [(4, group_id)]
                    })
                    request.env[
                        'paceflow.child.group'].browse(group_id).sudo().write({
                            'child_ids': [(4, child.id)]
                        })

            if parent_ids:
                for parent_id in parent_ids:
                    child.write({
                        'parent_ids': [(4, parent_id)]
                    })
                    request.env['paceflow.parents'].browse(parent_id).sudo().write({
                        'child_ids': [(4, child.id)]
                    })
            return request.redirect("/my/assessment_report/%s" % child.id)

        elif request.env.user.partner_id.is_parent:
            child = request.env['paceflow.child'].sudo().browse(
                                                    int(post['child_id']))
            child_partner = child.partner_id
            child_partner.sudo().write({
                'name': post['name'],
                'last_name': post['lastname'],
                'email': post['email'],
                'phone': post['code'] + ' ' + post['phone'],
                'hand': post.get('hand')
            })
            child_user = request.env['res.users'].sudo().search([
                ('partner_id', '=', child_partner.id)
            ])
            child_user.sudo().write({
                'name': post.get('name'),
                'last_name': post.get('lastname'),
                'login': post.get('email'),
            })
            if post['photo']:
                child_partner.sudo().write({
                    'image_1920': base64.b64encode(post.get('photo').read()),
                })
            child.sudo().write({
                'dob': post['dob'],
                'phone': post['code'] + ' ' + post['phone'],
                'email': post['email'],
            })
            return request.redirect("/my/assessment_report/%s" % child.id)

        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/get_dashboard_data'], type='json', auth='user',
           website=True)
    def get_dashboard_data(self, **post):
        """JSON REQUEST TO RENDER CHILD DASHBOARD DATA"""
        assessment = request.env['assessment.assessment'].sudo().browse(
            int(post['assessment_id'])
        )
        data = {
            'velocity': assessment.velocity,
            'summary_summary_score': int(round(assessment.summary_overall_score)),
            'overall_summary_score': round(assessment.summary_overall_score / 100),
            'legality': round(assessment.new_integer / 100),
            'legality_score': round(assessment.legality_score),
            'summary_legality_score': int(assessment.new_integer),
            'momentum_score': round(assessment.momentum_score / 100),
            'summary_momentum_score': int(round(assessment.momentum_score)),
            'stability_score': round(assessment.stability_score / 100),
            'summary_stability_score': int(round(assessment.stability_score)),
            'paceflow_score': round(assessment.paceflow_score / 100),
            'summary_paceflow_score': int(round(assessment.paceflow_score)),
            'rear_video': assessment.rear_video,
            'rear_reference': assessment.rear_reference,
            'side_video': assessment.side_video,
            'side_reference': assessment.side_reference,
            'img_summary_overall_1': assessment.img_summary_overall_1,
            'img_summary_overall_2': assessment.img_summary_overall_2,
        }

        if assessment.legality_drill_ids:
            legality_drills = []
            for legality_drill in assessment.legality_drill_ids:
                legality_drills.append({'name': legality_drill.name,
                                        'slide_type': legality_drill.slide_type,
                                        'slug': slug(legality_drill),
                                        'url': legality_drill.url})
            data.update({'legality_drills': legality_drills})

        if assessment.momentum_drill_ids:
            momentum_drills = []
            for momentum_drill in assessment.momentum_drill_ids:
                momentum_drills.append({'name': momentum_drill.name,
                                        'slide_type': momentum_drill.slide_type,
                                        'slug': slug(momentum_drill),
                                        'url': momentum_drill.url})
            data.update({'momentum_drills': momentum_drills})

        if assessment.stability_drill_ids:
            obj_rear_stability_drills = request.env['slide.slide'].sudo().search(
                [('id', 'in', assessment.stability_drill_ids.ids),
                 ('stability_rear', '=', True)])
            obj_side_stability_drills = request.env['slide.slide'].sudo().search(
                [('id', 'in', assessment.stability_drill_ids.ids),
                 ('stability_side', '=', True)])
            if obj_rear_stability_drills:
                rear_stability_drills = []
                for stability_drill in obj_rear_stability_drills:
                    rear_stability_drills.append({
                        'name': stability_drill.name,
                        'slide_type': stability_drill.slide_type,
                        'slug': slug(stability_drill),
                        'url': stability_drill.url})
                data.update({'rear_stability_drills': rear_stability_drills})
            if obj_side_stability_drills:
                side_stability_drills = []
                for stability_drill in obj_side_stability_drills:
                    side_stability_drills.append({
                        'name': stability_drill.name,
                        'slide_type': stability_drill.slide_type,
                        'slug': slug(stability_drill),
                        'url': stability_drill.url})
                data.update({'side_stability_drills': side_stability_drills})
            stability_drills = []
            for stability_drill in assessment.stability_drill_ids:
                stability_drills.append({
                     'name': stability_drill.name,
                     'slide_type': stability_drill.slide_type,
                     'slug': slug(stability_drill),
                     'url': stability_drill.url})
            data.update({'stability_drills': stability_drills})

        if assessment.paceflow_drill_ids:
            obj_rear_paceflow_drills = request.env['slide.slide'].sudo().search(
                [('id', 'in', assessment.paceflow_drill_ids.ids),
                 ('paceflow_rear', '=', True)])
            obj_side_paceflow_drills = request.env['slide.slide'].sudo().search(
                [('id', 'in', assessment.paceflow_drill_ids.ids),
                 ('paceflow_side', '=', True)])
            if obj_rear_paceflow_drills:
                rear_paceflow_drills = []
                for paceflow_drill in obj_rear_paceflow_drills:
                    rear_paceflow_drills.append({
                        'name': paceflow_drill.name,
                        'slide_type': paceflow_drill.slide_type,
                        'slug': slug(paceflow_drill),
                        'url': paceflow_drill.url})
                data.update({'rear_paceflow_drills': rear_paceflow_drills})
            if obj_side_paceflow_drills:
                side_paceflow_drills = []
                for paceflow_drill in obj_side_paceflow_drills:
                    side_paceflow_drills.append({
                        'name': paceflow_drill.name,
                        'slide_type': paceflow_drill.slide_type,
                        'slug': slug(paceflow_drill),
                        'url': paceflow_drill.url})
                data.update({'side_paceflow_drills': side_paceflow_drills})
            paceflow_drills = []
            for paceflow_drill in assessment.paceflow_drill_ids:
                paceflow_drills.append({
                    'name': paceflow_drill.name,
                    'slide_type': paceflow_drill.slide_type,
                    'slug': slug(paceflow_drill),
                    'url': paceflow_drill.url})
            data.update({'paceflow_drills': paceflow_drills})

        if assessment.legality_note_ids:
            legality_notes = []
            for note in assessment.legality_note_ids:
                legality_notes.append({'name': note.name,
                                       'description': note.description})
            data.update({'legality_notes': legality_notes})
        if assessment.momentum_note_ids:
            momentum_notes = []
            for note in assessment.momentum_note_ids:
                momentum_notes.append({'name': note.name,
                                       'description': note.description})
            data.update({'momentum_notes': momentum_notes})
        if assessment.stability_note_ids:

            obj_rear_stability_notes = request.env[
                'comment.comment'].sudo().search(
                [('id', 'in', assessment.stability_note_ids.ids),
                 ('stability_rear', '=', True)])

            obj_side_stability_notes = request.env[
                'comment.comment'].sudo().search(
                [('id', 'in', assessment.stability_note_ids.ids),
                 ('stability_side', '=', True)])

            if obj_rear_stability_notes:
                rear_stability_notes = []
                for note in obj_rear_stability_notes:
                    rear_stability_notes.append({
                        'name': note.name,
                        'description': note.description})
                data.update({'rear_stability_notes': rear_stability_notes})
            if obj_side_stability_notes:
                side_stability_notes = []
                for note in obj_side_stability_notes:
                    side_stability_notes.append({
                        'name': note.name,
                        'description': note.description})
                data.update({'side_stability_notes': side_stability_notes})
            stability_notes = []
            for note in assessment.stability_note_ids:
                stability_notes.append({'name': note.name,
                                        'description': note.description})
            data.update({'stability_notes': stability_notes})

        if assessment.paceflow_note_ids:
            obj_rear_paceflow_notes = request.env[
                'comment.comment'].sudo().search(
                [('id', 'in', assessment.paceflow_note_ids.ids),
                 ('paceflow_rear', '=', True)])
            obj_side_paceflow_notes = request.env[
                'comment.comment'].sudo().search(
                [('id', 'in', assessment.paceflow_note_ids.ids),
                 ('paceflow_side', '=', True)])

            if obj_rear_paceflow_notes:
                rear_paceflow_notes = []
                for note in obj_rear_paceflow_notes:
                    rear_paceflow_notes.append({
                        'name': note.name,
                        'description': note.description})
                data.update({'rear_paceflow_notes': rear_paceflow_notes})

            if obj_side_paceflow_notes:
                side_paceflow_notes = []
                for note in obj_side_paceflow_notes:
                    side_paceflow_notes.append({
                        'name': note.name,
                        'description': note.description})
                data.update({'side_paceflow_notes': side_paceflow_notes})
            paceflow_notes = []
            for note in assessment.paceflow_note_ids:
                paceflow_notes.append({
                    'name': note.name,
                    'description': note.description})
            data.update({'paceflow_notes': paceflow_notes})
        return data

    @route(['/my/child_cont', '/child_cont'],
           type='http', auth='user', website=True)
    def child(self):
        """CHILD HOME PAGE TEMPLATE"""
        if request.env.user.partner_id.is_parent:
            values = {}
            parent_partner = request.env.user.partner_id
            parent = request.env['paceflow.parents'].sudo().search([
                ('partner_id', '=', parent_partner.id)])
            child_contacts = parent.child_ids
            values.update({
                'parent_view': True,
                'child_contacts': child_contacts,
                'client_view': False
            })
            response = request.render("paceflow.paceflow_child", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        elif request.env.user.partner_id.is_client:
            values = {}
            partner = request.env.user.partner_id
            client = request.env['paceflow.client'].sudo().search(
                [('partner_id', '=', partner.id)])
            child_contacts = client.child_ids
            values.update({
                'client_view': True,
                'child_contacts': child_contacts,
                'parent_view': False,
            })
            response = request.render("paceflow.paceflow_child", values)
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/create_child'], type='http', auth='user', website=True)
    def create_child(self):
        """CREATE NEW CHILD TEMPLATE"""
        if not request.env.user.partner_id.is_client:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            coach_id = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', request.env.user.partner_id.id)
            ])
            groups = request.env['paceflow.child.group'].sudo().search([
                ('responsible_user', '=', coach_id.id)
            ])

            parents = request.env['paceflow.parents'].sudo().search([
                ('created_coach', '=', coach_id.id)])
            response = request.render("paceflow.create_child_template",
                                      {'groups': groups,
                                       'parents': parents})
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @route(['/my/create'], type='http', auth='user', website=True)
    def create(self, **post):
        """SUBMIT NEW CHILD"""
        partner = request.env.user.partner_id
        group_ids = list(map(int, request.httprequest.form.getlist('group')))
        parent_ids = list(map(int, request.httprequest.form.getlist('parent')))
        client = request.env['paceflow.client'].sudo().search(
            [('partner_id', '=', partner.id)])
        child_partner = request.env['res.partner'].sudo().create({
            'name': post['name'],
            'last_name': post['lastname'],
            'email': post['email'],
            'phone': post['code'] + ' ' + post['phone'],
            'dob': post['dob'],
        })
        child = request.env['paceflow.child'].sudo().create({
            'partner_id': child_partner.id,
            'email': post['email'],
            'phone': post['code'] + ' ' + post['phone'],
            'dob': post['dob'],
            'highest_standard': post['highestStd'],
        })
        child_user = request.env['res.users'].sudo().create({
            'name': post.get('name'),
            'last_name': post.get('lastname'),
            'login': post.get('email'),
            'partner_id': child_partner.id,
            'sel_groups_1_9_10': 9,
        })
        if post['photo']:
            child_partner.sudo().write({
                'image_1920': base64.b64encode(post.get('photo').read()),
            })
        child_partner.sudo().write({
            'is_child': True,
            'hand': post.get('hand')
        })
        client.sudo().write({
            'child_ids': [(4, child.id)],
        })
        child.sudo().write({
            'coach_ids': [(4, client.id)],
        })
        for group_id in group_ids:
            child.sudo().write({
                'group_ids': [(4, group_id)]
            })
            group = request.env['paceflow.child.group'].sudo().browse(group_id)
            group.sudo().write({
                'child_ids': [(4, child.id)]
            })
        for parent_id in parent_ids:
            child.sudo().write({
                'parent_ids': [(4, parent_id)]
            })
            parent = request.env['paceflow.parents'].sudo().browse(parent_id)
            parent.sudo().write({
                'child_ids': [(4, child.id)]
            })
        return request.redirect("/my/child_cont")

    @route(['/get_score_filter_data'], type='json', auth='user', website=True)
    def get_score_dashboard_data(self, **post):
        date_from = datetime.strptime(post['date_from'], '%Y-%m-%d')
        date_to = datetime.strptime(post['date_to'], '%Y-%m-%d')
        child_id = post['child_id']
        stage = request.env['assessment.stage'].sudo().browse(
            request.env.ref('paceflow.stage_done').id)

        assessments = request.env['assessment.assessment'].sudo().search(
            [('child_id', '=', int(child_id)), ('stage_id', '=', stage.id),
             ('create_date', '>=', date_from), ('create_date', '<=', date_to)],
            order='create_date asc', limit=10)
        x_axis = []
        y_axis = []
        for assessment in assessments:
            x_axis.append(assessment.name)
            y_axis.append(round(assessment.summary_overall_score))
        data = {
            'x_axis': x_axis,
            'y_axis': y_axis
        }
        return data

    # HISTORY FILTER JSON

    @route(['/get_history_filter_data'], type='json', auth='user', website=True)
    def history_dashboard_onchange(self, **post):
        date_from = datetime.strptime(post['date_from'], '%Y-%m-%d')
        date_to = datetime.strptime(post['date_to'], '%Y-%m-%d')
        child_id = post['child_id']
        stage = request.env['assessment.stage'].sudo().browse(
                request.env.ref('paceflow.stage_done').id)
        assessments = request.env['assessment.assessment'].sudo().search(
            [('child_id', '=', int(child_id)),
             ('stage_id', '=', stage.id), ('create_date', '>=', date_from),
             ('create_date', '<=', date_to)], order='create_date desc',
            limit=10)
        assessment_rev = assessments.sorted(key=lambda r: r.create_date)
        ass_info = []

        x_axis = []
        y_axis_score = []
        y_axis_speed = []
        y_axis_legality = []
        y_axis_momentum = []
        y_axis_stability = []
        y_axis_paceflow = []

        for ass in assessments:
            ass_info.append({'id': ass.id, 'name': ass.name})

        for ass_rev in assessment_rev:
            x_axis.append(ass_rev.report_date.strftime('%m-%d')),
            y_axis_score.append(
                round(ass_rev.summary_overall_score))
            y_axis_speed.append(ass_rev.velocity)
            y_axis_legality.append(ass_rev.legality_score)
            y_axis_momentum.append(round(ass_rev.momentum_score))
            y_axis_stability.append(round(ass_rev.stability_score))
            y_axis_paceflow.append(round(ass_rev.paceflow_score))

        paceflow_score = {
            'x_axis': x_axis,
            'y_axis_score': y_axis_score,
            'y_axis_speed': y_axis_speed,
            'y_axis_legality': y_axis_legality,
            'y_axis_momentum': y_axis_momentum,
            'y_axis_stability': y_axis_stability,
            'y_axis_paceflow': y_axis_paceflow
        }

        res = {
            'progress_dashboard': ass_info,
            'paceflow_score': paceflow_score,
        }
        return res

    @route(['/get_history_filter_clear_data'], type='json', auth='user',
           website=True)
    def history_dashboard_clear_filter(self, **post):
        child_id = post['child_id']
        stage = request.env['assessment.stage'].sudo().browse(
                request.env.ref('paceflow.stage_done').id)
        request.env.cr.execute(
            """ SELECT id, name FROM 
                assessment_assessment WHERE
                child_id = %s AND stage_id = %s
                ORDER BY create_date DESC
                LIMIT 10 """, [int(child_id), stage.id])
        ass_info = request.env.cr.dictfetchall()
        stage = request.env['assessment.stage'].browse(
            request.env.ref('paceflow.stage_done').id)
        child = request.env['paceflow.child'].browse([
            int(child_id)
        ])
        assessments = request.env['assessment.assessment'].search(
            [('stage_id', '=', stage.id), ('child_id', '=', child.id)],
            order='create_date asc', limit=10)

        x_axis_values = []

        y_axis_paceflow_score = []
        y_axis_ball_speed = []
        y_axis_legality = []
        y_axis_momentum = []
        y_axis_stability = []
        y_axis_paceflow = []

        for assessment in assessments:
            x_axis_values.append(assessment.report_date.strftime('%m-%d'))
            y_axis_paceflow_score.append(round(assessment.summary_overall_score))
            y_axis_ball_speed.append(assessment.velocity)
            y_axis_legality.append(assessment.legality_score)
            y_axis_momentum.append(round(assessment.momentum_score))
            y_axis_stability.append(round(assessment.stability_score))
            y_axis_paceflow.append(round(assessment.paceflow_score))

        paceflow_score = {
            'x_axis': x_axis_values,
            'y_axis_paceflow_score': y_axis_paceflow_score,
            'y_axis_ball_speed': y_axis_ball_speed,
            'y_axis_legality': y_axis_legality,
            'y_axis_momentum': y_axis_momentum,
            'y_axis_stability': y_axis_stability,
            'y_axis_paceflow': y_axis_paceflow
        }
        return {
            'progress_dashboard': ass_info,
            'paceflow_score': paceflow_score,
        }

    @route(['/get_assessment_data'], type='json', auth='user',
           website=True)
    def get_assessment_data(self, **post):
        """GET EACH ASSESSMENT DATA"""
        assessment = request.env['assessment.assessment'].sudo().browse(
            int(post['assessment_id'])
        )
        data = {
            'velocity': assessment.velocity,
            'summary_summary_score': int(
                round(assessment.summary_overall_score)),
            'overall_summary_score': round(
                assessment.summary_overall_score / 100),
            'legality': round(assessment.new_integer / 100),
            'legality_score': round(assessment.legality_score),
            'summary_legality_score': int(assessment.new_integer),
            'momentum_score': round(assessment.momentum_score / 100),
            'summary_momentum_score': int(round(assessment.momentum_score)),
            'stability_score': round(assessment.stability_score / 100),
            'summary_stability_score': int(round(assessment.stability_score)),
            'paceflow_score': round(assessment.paceflow_score / 100),
            'summary_paceflow_score': int(round(assessment.paceflow_score)),
            'img_legality_overall': assessment.img_legality_overall,
            'img_momentum_overall': assessment.img_momentum_overall,
            'img_stability_overall_1': assessment.img_stability_overall_1,
            'img_stability_overall_2': assessment.img_stability_overall_2,
            'img_paceflow_overall_1': assessment.img_paceflow_overall_1,
            'img_paceflow_overall_2': assessment.img_paceflow_overall_2,
        }
        if assessment.legality_drill_ids:
            legality_drills = []
            for legality_drill in assessment.legality_drill_ids:
                legality_drills.append({
                    'name': legality_drill.name,
                    'slide_type': legality_drill.slide_type,
                    'slug': slug(legality_drill),
                    'url': legality_drill.url})
            data.update({'legality_drills': legality_drills})
        if assessment.momentum_drill_ids:
            momentum_drills = []
            for momentum_drill in assessment.momentum_drill_ids:
                momentum_drills.append({
                    'name': momentum_drill.name,
                    'slide_type': momentum_drill.slide_type,
                    'slug': slug(momentum_drill),
                    'url': momentum_drill.url})
            data.update({'momentum_drills': momentum_drills})
        if assessment.stability_drill_ids:
            obj_rear_stability_drills = request.env[
                'slide.slide'].sudo().search(
                [('id', 'in', assessment.stability_drill_ids.ids),
                 ('stability_rear', '=', True)])
            obj_side_stability_drills = request.env[
                'slide.slide'].sudo().search(
                [('id', 'in', assessment.stability_drill_ids.ids),
                 ('stability_side', '=', True)])
            if obj_rear_stability_drills:
                rear_stability_drills = []
                for stability_drill in obj_rear_stability_drills:
                    rear_stability_drills.append({
                        'name': stability_drill.name,
                        'slide_type': stability_drill.slide_type,
                        'slug': slug(stability_drill),
                        'url': stability_drill.url})
                data.update({'rear_stability_drills': rear_stability_drills})
            if obj_side_stability_drills:
                side_stability_drills = []
                for stability_drill in obj_side_stability_drills:
                    side_stability_drills.append({
                        'name': stability_drill.name,
                        'slide_type': stability_drill.slide_type,
                        'slug': slug(stability_drill),
                        'url': stability_drill.url})
                data.update({'side_stability_drills': side_stability_drills})
            stability_drills = []
            for stability_drill in assessment.stability_drill_ids:
                stability_drills.append({
                    'name': stability_drill.name,
                    'slide_type': stability_drill.slide_type,
                    'slug': slug(stability_drill),
                    'url': stability_drill.url})
            data.update({'stability_drills': stability_drills})
        if assessment.paceflow_drill_ids:
            obj_rear_paceflow_drills = request.env[
                'slide.slide'].sudo().search(
                [('id', 'in', assessment.paceflow_drill_ids.ids),
                 ('paceflow_rear', '=', True)])
            obj_side_paceflow_drills = request.env[
                'slide.slide'].sudo().search(
                [('id', 'in', assessment.paceflow_drill_ids.ids),
                 ('paceflow_side', '=', True)])
            if obj_rear_paceflow_drills:
                rear_paceflow_drills = []
                for paceflow_drill in obj_rear_paceflow_drills:
                    rear_paceflow_drills.append({
                        'name': paceflow_drill.name,
                        'slide_type': paceflow_drill.slide_type,
                        'slug': slug(paceflow_drill),
                        'url': paceflow_drill.url})
                data.update({'rear_paceflow_drills': rear_paceflow_drills})
            if obj_side_paceflow_drills:
                side_paceflow_drills = []
                for paceflow_drill in obj_side_paceflow_drills:
                    side_paceflow_drills.append({
                        'name': paceflow_drill.name,
                        'slide_type': paceflow_drill.slide_type,
                        'slug': slug(paceflow_drill),
                        'url': paceflow_drill.url})
                data.update({'side_paceflow_drills': side_paceflow_drills})
            paceflow_drills = []
            for paceflow_drill in assessment.paceflow_drill_ids:
                paceflow_drills.append({
                    'name': paceflow_drill.name,
                    'slide_type': paceflow_drill.slide_type,
                    'slug': slug(paceflow_drill),
                    'url': paceflow_drill.url})
            data.update({'paceflow_drills': paceflow_drills})
        return data

    @route(['/get_group_data'], type='json', auth='user',
           website=True)
    def get_group_data(self, **post):
        values = []
        names = []
        group = request.env['paceflow.child.group'].sudo().browse(int(
            post['group_id']
        ))
        stage = request.env['assessment.stage'].sudo().browse(
            request.env.ref('paceflow.stage_done').id)
        childs = group.child_ids
        for child in childs:
            last_assessment_score = 0
            average_10 = 0
            average_top = 0
            names.append(child.name)
            last_assessment = request.env['assessment.assessment'].sudo().search([
                ('child_id', '=', child.id), ('stage_id', '=', stage.id)],
                order='create_date desc', limit=1)
            if last_assessment.id:
                last_assessment_score = round(
                    last_assessment.summary_overall_score)

            last_assessment_10 = request.env['assessment.assessment'].sudo().search([
                ('child_id', '=', child.id), ('stage_id', '=', stage.id)],
                order='create_date desc', limit=10)
            overall_list = last_assessment_10.mapped('summary_overall_score')
            total = 0.00
            if not overall_list:
                average_10 = 0
            else:
                for rec in overall_list:
                    total += rec
                average_10 = round(total / len(overall_list))

            all_assessment = request.env['assessment.assessment'].sudo().search([
                ('child_id', '=', child.id), ('stage_id', '=', stage.id)],
                order='create_date desc')

            overall_top = all_assessment.mapped('summary_overall_score')
            total_top = 0.00
            if not overall_top:
                average_top = 0
            else:
                for rec in overall_top:
                    total_top += rec
                average_top = round(total / len(overall_list))
            child_details = {
                'name': child.partner_id.name + ' ' + child.partner_id.last_name,
                'last_session_score': last_assessment_score,
                'last_10_assessment_score': average_10,
                'top_performance': average_top
            }
            values.append(child_details)
        last_session_sort = sorted(
            values, key=lambda i: i['last_session_score'], reverse=True)
        last_10_session_sort = sorted(
            values, key=lambda i: i['last_10_assessment_score'], reverse=True)
        top_performance_sort = sorted(
            values, key=lambda i: i['top_performance'], reverse=True)
        return last_session_sort, last_10_session_sort, top_performance_sort

    @route(['/my/settings', '/settings'], type='http', auth='user', website=True)
    def settings_dashboard(self):
        """RENDER SETTINGS PAGE TEMPLATE"""
        response = request.render("paceflow.settings_dashboard")
        response.headers['X-Frame-Options'] = 'DENY'
        return response

    @http.route(['/my/invoices', '/my/invoices/page/<int:page>'], type='http',
                auth="user", website=True)
    def portal_my_invoices(self, page=1, date_begin=None, date_end=None,
                           sortby=None, filterby=None, **kw):
        """RENDER INVOICES"""
        if request.env.user.partner_id.is_parent:
            parent_partner = request.env.user.partner_id
            values = self._prepare_portal_layout_values()
            parent = request.env['paceflow.parents'].sudo().search([
                ('partner_id', '=', parent_partner.id)
            ])
            childs = parent.child_ids
            child_partners = childs.mapped('partner_id')
            AccountInvoice = request.env['account.move']
            domain = self._get_invoices_domain()
            domain += [(
                'partner_id', 'in', parent_partner.ids + child_partners.ids)]
            searchbar_sortings = {
                'date': {'label': _('Date'), 'order': 'invoice_date desc'},
                'duedate': {'label': _('Due Date'),
                            'order': 'invoice_date_due desc'},
                'name': {'label': _('Reference'), 'order': 'name desc'},
                'state': {'label': _('Status'), 'order': 'state'},
            }
            # default sort by order
            if not sortby:
                sortby = 'date'
            order = searchbar_sortings[sortby]['order']

            searchbar_filters = {
                'all': {'label': _('All'), 'domain': []},
                'invoices': {'label': _('Invoices'), 'domain': [
                    ('move_type', '=', ('out_invoice', 'out_refund'))]},
                'bills': {'label': _('Bills'), 'domain': [
                    ('move_type', '=', ('in_invoice', 'in_refund'))]},
            }
            # default filter by value
            if not filterby:
                filterby = 'all'
            domain += searchbar_filters[filterby]['domain']

            if date_begin and date_end:
                domain += [('create_date', '>', date_begin),
                           ('create_date', '<=', date_end)]

            # count for pager
            invoice_count = AccountInvoice.sudo().search_count(domain)
            # pager
            pager = portal_pager(
                url="/my/invoices",
                url_args={'date_begin': date_begin, 'date_end': date_end,
                          'sortby': sortby},
                total=invoice_count,
                page=page,
                step=self._items_per_page
            )
            # content according to pager and archive selected
            invoices = AccountInvoice.sudo().search(
                domain, order=order,
                limit=self._items_per_page,
                offset=pager['offset'])
            request.session['my_invoices_history'] = invoices.ids[:100]
            values.update({
                'date': date_begin,
                'invoices': invoices,
                'page_name': 'invoice',
                'pager': pager,
                'default_url': '/my/invoices',
                'searchbar_sortings': searchbar_sortings,
                'sortby': sortby,
                'searchbar_filters': OrderedDict(
                    sorted(searchbar_filters.items())),
                'filterby': filterby,
            })
            return request.render("account.portal_my_invoices", values)

        elif request.env.user.partner_id.is_child:
            child_partner = request.env.user.partner_id
            child = request.env['paceflow.child'].search([
                ('partner_id', '=', child_partner.id)
            ])
            difference = relativedelta(date.today(), child.dob)
            if int(difference.years) >= 18:
                values = self._prepare_portal_layout_values()
                AccountInvoice = request.env['account.move']
                domain = self._get_invoices_domain()
                domain += [(
                    'partner_id', '=', child_partner.id)]
                searchbar_sortings = {
                    'date': {'label': _('Date'), 'order': 'invoice_date desc'},
                    'duedate': {'label': _('Due Date'),
                                'order': 'invoice_date_due desc'},
                    'name': {'label': _('Reference'), 'order': 'name desc'},
                    'state': {'label': _('Status'), 'order': 'state'},
                }
                # default sort by order
                if not sortby:
                    sortby = 'date'
                order = searchbar_sortings[sortby]['order']

                searchbar_filters = {
                    'all': {'label': _('All'), 'domain': []},
                    'invoices': {'label': _('Invoices'), 'domain': [
                        ('move_type', '=', ('out_invoice', 'out_refund'))]},
                    'bills': {'label': _('Bills'), 'domain': [
                        ('move_type', '=', ('in_invoice', 'in_refund'))]},
                }
                # default filter by value
                if not filterby:
                    filterby = 'all'
                domain += searchbar_filters[filterby]['domain']

                if date_begin and date_end:
                    domain += [('create_date', '>', date_begin),
                               ('create_date', '<=', date_end)]

                # count for pager
                invoice_count = AccountInvoice.sudo().search_count(domain)
                # pager
                pager = portal_pager(
                    url="/my/invoices",
                    url_args={'date_begin': date_begin, 'date_end': date_end,
                              'sortby': sortby},
                    total=invoice_count,
                    page=page,
                    step=self._items_per_page
                )
                # content according to pager and archive selected
                invoices = AccountInvoice.sudo().search(
                    domain, order=order,
                    limit=self._items_per_page,
                    offset=pager['offset'])
                request.session['my_invoices_history'] = invoices.ids[:100]
                values.update({
                    'date': date_begin,
                    'invoices': invoices,
                    'page_name': 'invoice',
                    'pager': pager,
                    'default_url': '/my/invoices',
                    'searchbar_sortings': searchbar_sortings,
                    'sortby': sortby,
                    'searchbar_filters': OrderedDict(
                        sorted(searchbar_filters.items())),
                    'filterby': filterby,
                })
                return request.render("account.portal_my_invoices", values)
            else:
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response

        elif request.env.user.partner_id.is_client:
            coach_partner = request.env.user.partner_id
            values = self._prepare_portal_layout_values()
            coach = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', coach_partner.id)
            ])
            childs = coach.child_ids
            child_partners = childs.mapped('partner_id')
            parents = request.env['paceflow.parents'].sudo().search([
                ('created_coach', '=', coach.id)
            ])
            parent_partners = parents.mapped('partner_id')
            AccountInvoice = request.env['account.move']
            domain = self._get_invoices_domain()
            domain += [
                ('partner_id', 'in', coach_partner.ids + child_partners.ids + parent_partners.ids)]
            searchbar_sortings = {
                'date': {'label': _('Date'), 'order': 'invoice_date desc'},
                'duedate': {'label': _('Due Date'),
                            'order': 'invoice_date_due desc'},
                'name': {'label': _('Reference'), 'order': 'name desc'},
                'state': {'label': _('Status'), 'order': 'state'},
            }
            # default sort by order
            if not sortby:
                sortby = 'date'
            order = searchbar_sortings[sortby]['order']

            searchbar_filters = {
                'all': {'label': _('All'), 'domain': []},
                'invoices': {'label': _('Invoices'), 'domain': [
                    ('move_type', '=', ('out_invoice', 'out_refund'))]},
                'bills': {'label': _('Bills'), 'domain': [
                    ('move_type', '=', ('in_invoice', 'in_refund'))]},
            }
            # default filter by value
            if not filterby:
                filterby = 'all'
            domain += searchbar_filters[filterby]['domain']

            if date_begin and date_end:
                domain += [('create_date', '>', date_begin),
                           ('create_date', '<=', date_end)]

            # count for pager
            invoice_count = AccountInvoice.sudo().search_count(domain)
            # pager
            pager = portal_pager(
                url="/my/invoices",
                url_args={'date_begin': date_begin, 'date_end': date_end,
                          'sortby': sortby},
                total=invoice_count,
                page=page,
                step=self._items_per_page
            )
            # content according to pager and archive selected
            invoices = AccountInvoice.sudo().search(domain, order=order,
                                                    limit=self._items_per_page,
                                                    offset=pager['offset'])
            request.session['my_invoices_history'] = invoices.ids[:100]
            values.update({
                'date': date_begin,
                'invoices': invoices,
                'page_name': 'invoice',
                'pager': pager,
                'default_url': '/my/invoices',
                'searchbar_sortings': searchbar_sortings,
                'sortby': sortby,
                'searchbar_filters': OrderedDict(
                    sorted(searchbar_filters.items())),
                'filterby': filterby,
            })
            return request.render("account.portal_my_invoices", values)

# ONBOARDINGSSSSS

    @http.route(['/my/on_board_player', '/on_board_player'],
                type='http', auth='user', website=True)
    def onboard_player(self):
        partner = request.env.user.partner_id
        coach = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', partner.id)])
        if partner.is_client:
            response = request.render("paceflow.on_board_players")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/on_board_player_create', '/on_board_player_create'],
                type='http', auth='user', website=True)
    def onboard_player_create(self, **post):
        partner = request.env.user.partner_id
        coach = request.env['paceflow.client'].sudo().search(
                            [('partner_id', '=', partner.id)])
        if partner.is_client:
            client = request.env['paceflow.client'].sudo().search(
                            [('partner_id', '=', partner.id)])
            child_partner = request.env['res.partner'].sudo().create({
                'name': post['name'],
                'last_name': post['lastname'],
                'email': post['email'],
                'phone': post['code'] + ' ' + post['phone'],
                'dob': post['dob'],
            })
            child = request.env['paceflow.child'].sudo().create({
                'partner_id': child_partner.id,
                'email': post['email'],
                'phone': post['code'] + ' ' + post['phone'],
                'dob': post['dob'],
                'highest_standard': post['highestStd'],
            })
            child_user = request.env['res.users'].sudo().create({
                'name': post.get('name'),
                'last_name': post.get('lastname'),
                'login': post.get('email'),
                'partner_id': child_partner.id,
                'sel_groups_1_9_10': 9,
            })
            child_partner.sudo().write({
                'is_child': True,
                'hand': post.get('hand')
            })
            client.sudo().write({
                'child_ids': [(4, child.id)],
            })
            child.sudo().write({
                'coach_ids': [(4, client.id)],
            })
            return request.redirect("/my/on_board_group")
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/on_board_group', '/on_board_group'],
                type='http', auth='user', website=True)
    def onboard_group(self):
        partner = request.env.user.partner_id
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', partner.id)])
        if partner.is_client:
            players = coach_id.child_ids

            response = request.render("paceflow.on_board_group",
                                      {'players': players})
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/on_board_group_create', '/on_board_group_create'],
                type='http', auth='user', website=True)
    def onboard_group_create(self, **post):
        partner = request.env.user.partner_id
        coach = request.env['paceflow.client'].sudo().search(
            [('partner_id', '=', partner.id)])
        if partner.is_client:
            child_ids = list(map(int,
                                 request.httprequest.form.getlist('childs')))

            group = request.env['paceflow.child.group'].sudo().create({
                'name': post.get('group-name'),
                'description': post.get('group-description'),
                'responsible_user': coach.id
            })
            if child_ids:
                for child_id in child_ids:
                    group.write({
                        'child_ids': [(4, child_id)]
                    })
                    request.env['paceflow.child'].browse(child_id).sudo().write(
                        {
                            'group_ids': [(4, group.id)]
                        })
            coach.sudo().write({
                'group_ids': [(4, group.id)]
            })
            return request.redirect("/my/on_board_parent")
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/on_board_parent', '/on_board_parent'],
                type='http', auth='user', website=True)
    def onboard_parent(self):
        partner = request.env.user.partner_id
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', partner.id)])
        if partner.is_client:
            players = coach_id.child_ids
            response = request.render("paceflow.on_board_parent",
                                      {'players': players})
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/on_board_parent_create', '/on_board_parent_create'],
                type='http', auth='user', website=True)
    def onboard_parent_create(self, **post):
        partner = request.env.user.partner_id
        coach_id = request.env['paceflow.client'].sudo().search([
            ('partner_id', '=', partner.id)])
        if partner.is_client:
            child_ids = list(map(int,
                                 request.httprequest.form.getlist('childs')))
            parent_partner = request.env['res.partner'].sudo().create({
                'name': post.get('firstname'),
                'last_name': post.get('lastname'),
                'email': post.get('email'),
                'phone': post.get('tele_code') + ' ' + post.get('telephone')
            })
            parent = request.env['paceflow.parents'].sudo().create({
                'partner_id': parent_partner.id,
                'email': post.get('email'),
                'phone': post.get('tele_code') + ' ' + post.get('telephone'),
                'created_coach': coach_id.id,
                'emergency_number': post.get('emer_code') + ' ' + post.get(
                    'emergency')
            })
            parent_user = request.env['res.users'].sudo().create({
                'name': post.get('firstname'),
                'last_name': post.get('lastname'),
                'login': post.get('email'),
                'partner_id': parent_partner.id,
                'sel_groups_1_9_10': 9,
            })
            if child_ids:
                for child_id in child_ids:
                    parent.sudo().write({
                        'child_ids': [(4, child_id)]})
                    request.env['paceflow.child'].browse(
                        child_id).sudo().write({
                            'parent_ids': [(4, parent.id)]
                    })
            parent.partner_id.sudo().write({
                'is_parent': True,
            })
            return request.redirect("/my/finish_onboard")
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response

    @http.route(['/my/finish_onboard', '/finish_onboard'],
                type='http', auth='user', website=True)
    def finish_onboard(self):
        partner = request.env.user.partner_id
        if partner.is_client:
            response = request.render("paceflow.on_board_finish")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
