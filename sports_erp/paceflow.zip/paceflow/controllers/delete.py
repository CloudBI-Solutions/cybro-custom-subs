import base64

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class Delete(CustomerPortal):
    @route(['/delete/child/<int:child_id>',
            '/assessment_report/<int:child_id>'],
           type='http', auth='user', website=True)
    def delete_athlete(self, child_id=None):
        """DELETE CHILD"""
        if request.env.user.partner_id.is_client:
            partner = request.env.user.partner_id
            child = request.env['paceflow.child'].sudo().browse(
                int(child_id))
            child_partner = child.partner_id
            child_user = request.env['res.users'].sudo().search(
                [('partner_id', '=', child_partner.id)])
            client = request.env['paceflow.client'].sudo().search([
                ('partner_id', '=', partner.id)])
            client_children = client.child_ids
            if child.id not in client_children.mapped('id'):
                response = request.render("paceflow.portal_forbidden")
                response.headers['X-Frame-Options'] = 'DENY'
                return response
            assessments = request.env['assessment.assessment'].search([
                ('child_id', '=', child.id)
            ])
            for rec in assessments:
                rec.unlink()
            child.unlink()
            child_user.unlink()
            child_partner.unlink()
            response = request.redirect("/my/child_cont")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
        else:
            response = request.render("paceflow.portal_forbidden")
            response.headers['X-Frame-Options'] = 'DENY'
            return response
