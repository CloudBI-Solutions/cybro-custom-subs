
import json
from odoo import fields, _
import logging
from odoo import http
from odoo.http import request, route
from datetime import datetime
import pytz
from datetime import timedelta
from odoo.addons.website.controllers import form

from odoo.exceptions import AccessError, MissingError, UserError

_logger = logging.getLogger(__name__)


class BadmintooController(http.Controller):

    @route(['/my/badmintoo/assessment',
            '/my/badmintoo/assessment/page/<int:page>'], type='http', auth='user', website=True)
    def my_badmintoo_assessment(self, search=None, page=0, **kw):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
        org_domain = []
        if request.env.user.has_group(
                'organisation.group_organisation_administrator'):
            org_domain.append(('allowed_user_ids', 'in', [request.env.user.id]))
        elif request.env.user.has_group(
                'organisation.group_organisation_coaches'):
            coach_ids = request.env['organisation.coaches'].search(
                [('partner_id', '=', request.env.user.partner_id.id)])
            organisations = coach_ids.mapped('organisation_ids')
            org_domain.append(('id', 'in', organisations.ids))
        elif request.env.user.has_group(
                'organisation.group_organisation_athletes'):
            athlete_ids = request.env['organisation.athletes'].search(
                [('partner_id', '=', request.env.user.partner_id.id)])
            organisations = athlete_ids.mapped('organisation_ids')
            org_domain.append(('id', 'in', organisations.ids))
        elif request.env.user.has_group(
                'organisation.group_organisation_parents'):
            parents = request.env['organisation.parents'].sudo().search(
                [('partner_id', '=', request.env.user.partner_id.id)])
            organisations = parents.mapped('organisation_ids')
            org_domain.append(('id', 'in', organisations.ids))
        else:
            raise AccessError(
                _("Sorry you are not allowed to access this document"))
        if request.httprequest.cookies.get('select_organisation') is not None:
            org_domain.append(('id', '=',
                               request.httprequest.cookies.get(
                                   'select_organisation')))
        organisation = None
        if org_domain:
            organisation = request.env[
                'organisation.organisation'].sudo().search(
                org_domain, limit=1)
            if organisation:
                domain.append(('organisation_id', '=', organisation.id))
        print(domain)
        assessments = request.env['badminto.assessment'].sudo().search(
            domain)
        total = len(assessments)
        pager = request.website.pager(
            url='/my/registers',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        assessments = assessments[offset: offset + 6]
        # if request.env.user.has_group(
        #         'organisation.group_organisation_athletes'):
        print(assessments, "assessments")
        values = {
            'search': search,
            'assessments': assessments,
            'total': total,
            'pager': pager,
            'is_account': True,
        }
        return request.render('badminto.assessment_template', values)

    # Assessment

    @http.route(['/my/badmintoo/assessment/<int:assessment_id>'],
                type='http', auth='user', website=True)
    def assessment_assessment(self, **kwargs):
        print("Assessment", kwargs)
        values = {
            'is_account': True,
        }
        return request.render(
            'badminto.general_assessment_template', values)
