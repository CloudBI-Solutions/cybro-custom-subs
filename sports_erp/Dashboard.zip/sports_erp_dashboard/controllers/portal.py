import base64
import json

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class Organisation(CustomerPortal):

    @route(['/my', '/my/home'], type='http', auth="user", website=True)
    def home(self, **kw):
        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        if partner.org_group_selection == 'parents':
            organisation = request.env['organisation.organisation'].sudo().search(
                [('partner_id', '=', partner.id)])
            athletes = organisation.athlete_ids
            values.update({
                'partner': partner,
                # 'athletes': athletes,
                'page_name': 'organisation'
            })
            response = request.render("organisation.portal_organisation_dashboard",
                                      values)
        if partner.org_group_selection == 'parents':
            parent = request.env['organisation.parents'].sudo().search(
                [('partner_id', '=', partner.id)])
            athletes = parent.athlete_ids
            values.update({
                'partner': partner,
                'athletes': athletes,
                'page_name': 'athlete_list'
            })
            response = request.render("organisation.portal_athlete_list",
                                      values)
            return response
        if partner.org_group_selection == 'athletes':
            athlete = request.env['organisation.athletes'].sudo().search(
                [('partner_id', '=', partner.id)])
            tasks = athlete.task_ids
            links = request.env['athlete.dashboard.link'].sudo().search([])
            values.update({
                'partner': partner,
                'athlete': athlete,
                'tasks': tasks,
                'links': links,
            })
            params = request.env['ir.config_parameter'].sudo()
            athlete_profile = params.get_param('organisation.athlete_profile')
            athlete_booking = params.get_param('organisation.athlete_booking')
            athlete_calendar = params.get_param('organisation.athlete_calendar')
            athlete_products = params.get_param('organisation.athlete_products')
            athlete_forms = params.get_param('organisation.athlete_forms')
            athlete_documents = params.get_param(
                'organisation.athlete_documents')
            athlete_timesheet = params.get_param(
                'organisation.athlete_timesheet')
            athlete_coaches = params.get_param('organisation.athlete_coaches')
            athlete_invoices = params.get_param('organisation.athlete_invoices')
            athlete_parents = params.get_param('organisation.athlete_parents')
            athlete_chat_hub = params.get_param('organisation.athlete_chat_hub')
            athlete_assignments = params.get_param(
                'organisation.athlete_assignments')
            athlete_attendance = params.get_param(
                'organisation.athlete_attendance')
            mobile = params.get_param('organisation.mobile')
            tablet = params.get_param('organisation.tablet')
            desktop = params.get_param('organisation.desktop')
            values.update({
                'athlete_profile': athlete_profile,
                'athlete_booking': athlete_booking,
                'athlete_calendar': athlete_calendar,
                'athlete_products': athlete_products,
                'athlete_forms': athlete_forms,
                'athlete_documents': athlete_documents,
                'athlete_timesheet': athlete_timesheet,
                'athlete_coaches': athlete_coaches,
                'athlete_invoices': athlete_invoices,
                'athlete_parents': athlete_parents,
                'athlete_chat_hub': athlete_chat_hub,
                'athlete_assignments': athlete_assignments,
                'athlete_attendance': athlete_attendance,
                'mobile': mobile,
                'tablet': tablet,
                'desktop': desktop
            })
            response = request.render(
                "organisation.portal_organisation_dashboard", values)
            return response
        if partner.org_group_selection == 'fans':
            fan = request.env['organisation.fans'].sudo().search(
                [('partner_id', '=', partner.id)])
            links = request.env['fan.dashboard.link'].sudo().search([])
            values.update({
                'links': links,
                'partner': partner,
                'fan': fan,
            })
            params = request.env['ir.config_parameter'].sudo()
            fan_profile = params.get_param('organisation.fan_profile')
            fan_booking = params.get_param('organisation.fan_booking')
            fan_calendar = params.get_param('organisation.fan_calendar')
            mobile = params.get_param('organisation.mobile')
            tablet = params.get_param('organisation.tablet')
            desktop = params.get_param('organisation.desktop')
            values.update({
                'fan_profile': fan_profile,
                'fan_booking': fan_booking,
                'fan_calendar': fan_calendar,
                'mobile': mobile,
                'tablet': tablet,
                'desktop': desktop,
            })
            response = request.render(
                "organisation.portal_fans_dashboard", values)
            return response
        values.update({
            'partner': partner,
            'is_account': True
        })
        return request.render("portal.portal_my_home", values)

    @http.route(['/my/coaches', '/my/coaches/page/<int:page>'], type='http', auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_coaches(self, page=0, search='', **post):
        print("self....")
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
        if search:
            post["search"] = search
        coaches = request.env['organisation.coaches'].sudo().search([])
        total = coaches.sudo().search_count([])
        pager = request.website.pager(
            url='/my/coaches',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        coaches = coaches[offset: offset + 5]
        print(pager, "pager")
        return request.render('sports_erp_dashboard.coach_dashboard_template', {
            'search': search,
            'coaches': coaches,
            'pager': pager,
            'is_account': True
        })

    @http.route('/create/coach', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_coach(self, **post):
        if post:
            print(post, "post....")
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            athlete_ids = list(
                map(int, request.httprequest.form.getlist('athletes')))
            group_ids = list(
                map(int, request.httprequest.form.getlist('groups')))
            discipline_ids = list(
                map(int, request.httprequest.form.getlist('disciplines')))
            document_ids = list(
                map(int, request.httprequest.form.getlist('documents')))
            values = {
                'partner_id': int(post.get('partner')),
                'phone': post.get('phone'),
                'email': post.get('email'),
                'create_booking': post.get('booking'),
                'price_o2o': post.get('onetoprice'),
                'price_team': post.get('teamprice'),
                'employee_id': int(post.get('employee')),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
                'group_ids': [(4, group) for group in group_ids],
                'discipline_ids': [(4, discipline) for discipline in discipline_ids],
                'athlete_ids': [(4, athlete) for athlete in athlete_ids],
                'document_ids': [(4, document) for document in document_ids],
            }
            coach = request.env['organisation.coaches'].sudo().create(values)
            return request.redirect('/my/coaches')

    @http.route('/remove/<model("organisation.coaches"):coach_id>', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_coach(self, coach_id=None):
        if coach_id:
            coach_id.sudo().unlink()
        return request.redirect('/my/coaches')

    @http.route('/my/coach/<model("organisation.coaches"):coach_id>', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def coach_details(self, coach_id=None):
        values = {
            'coach': coach_id,
            'is_account': True
        }
        return request.render('sports_erp_dashboard.coach_dashboard_details_template', values)

    @http.route('/update',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def update_coach(self, **post):
        print(post, "post")
        values = {
            'name': post.get('name'),
            'email': post.get('email'),
            'phone': post.get('phone')
        }
        coach = request.env['organisation.coaches'].sudo().browse(int(post.get('coach')))
        coach.sudo().write(values)
        return request.redirect('/my/coach/%s' % coach.id)

    @http.route(['/my/athletes/home', '/my/athletes/home/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_athletes_home(self, page=0, search='', **post):
        print("self....")
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
        if search:
            post["search"] = search
        athletes = request.env['organisation.athletes'].sudo().search([])
        total = athletes.sudo().search_count([])
        pager = request.website.pager(
            url='/my/athletes/home',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        athletes = athletes[offset: offset + 5]
        return request.render('sports_erp_dashboard.athlete_dashboard_template', {
            'search': search,
            'athletes': athletes,
            'pager': pager,
            'is_account': True
        })
