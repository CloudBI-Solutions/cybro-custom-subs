odoo.define('sports_erp_dashboard.coach', function (require) {
    "use strict";
    const dom = require('web.dom');
    var publicWidget = require('web.public.widget');
    var PortalSidebar = require('portal.PortalSidebar');
    var utils = require('web.utils');
    var rpc = require('web.rpc');

    $(document).ready(function () {
      $('.sports-erp-dashbaord-select').select2();
    });

    publicWidget.registry.CoachPage = publicWidget.Widget.extend({
        selector: '.se-modal__dialog',
        events: {
            'change #contact': '_onChangeContact',
        },
        _onChangeContact: function (ev) {
            rpc.query({
                    method: 'search_read',
                    model: 'res.partner',
                    args: [[['id', '=', ev.currentTarget.value]]],
                }).then(function(result) {
                    $('#phone').val(result[0]['phone']);
                    $('#email').val(result[0]['email']);
                });
        },
        /**
         * @override
         */

    });
});