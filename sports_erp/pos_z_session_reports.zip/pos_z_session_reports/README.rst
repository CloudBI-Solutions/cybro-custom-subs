POS Session Reports
==================
This Point of sales module will allow user to print POS Current and Closed Session Reports which consist total
transaction and sales summary report at End of shift and total sales summary of session. You can generate report for
Current and Closed sessions in PDF format and This odoo apps is POS-BOX Compatible.

Configuration
=============
Under point of sale configuration you can tick on 'Enable Session Report' checkbox for print current session report
directly from POS screen.

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
Developer: Athira Premanand @cybrosys, Contact: odoo@cybrosys.com

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__

