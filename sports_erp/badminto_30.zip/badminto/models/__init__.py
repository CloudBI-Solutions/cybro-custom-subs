from . import badminto_assessment
from . import assessment_type
from . import res_config_settings
from . import assessment_plan
from . import technical_assessment_configuration
from . import organisation
