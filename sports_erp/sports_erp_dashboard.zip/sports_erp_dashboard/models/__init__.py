from . import res_partner
from . import res_users
from . import subscriptions
from . import home
from . import events
