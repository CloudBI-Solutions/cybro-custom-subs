from . import main
from . import upload_videos
from . import assessment_plan
from . import badmintoo_products
from . import technical
