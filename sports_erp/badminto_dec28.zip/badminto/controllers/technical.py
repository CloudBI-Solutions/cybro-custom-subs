
import json
from odoo import fields, _
import logging
from odoo import http
from odoo.http import request, route
from odoo.addons.survey.controllers.main import Survey
import werkzeug
from datetime import datetime
import pytz
from datetime import timedelta
from odoo.addons.website.controllers import form


class TechnicalAssessmentController(http.Controller):

    @route(['/my/technical/assessment/sr'],
           type='http', auth='user', website=True)
    def technical_sr(self, **kw):
        assessment = request.env['badminto.assessment'].sudo().browse(
            int(kw.get('assessment')))

        organisation_id = request.env[
            'organisation.organisation'].sudo().search(
            [('partner_id', '=', request.env.user.partner_id.id)])

        in_service_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.in_service_technical'))
        in_receive_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.in_receiving_technical'))

        if assessment.service_grip and assessment.service_sp and \
                assessment.service_bp and assessment.service_be and \
                assessment.service_fs and assessment.service_toi and \
                assessment.service_ft:
            service_complete = True
        else:
            service_complete = False
        if assessment.receiving_grip and assessment.receiving_sp and \
                assessment.receiving_bp and assessment.receiving_be and \
                assessment.receiving_fs and assessment.receiving_toi and \
                assessment.receiving_ft:
            receiving_complete = True
        else:
            receiving_complete = False
        values = {
            'is_account': True,
            'assessment': assessment,
            'organisation': organisation_id,
            'service_complete': service_complete,
            'receiving_complete': receiving_complete,
            'in_service': in_service_values,
            'in_receiving': in_receive_values,
        }
        return request.render('badminto.technical_sr_template', values)

    @route(['/my/technical/assessment/fnz'],
           type='http', auth='user', website=True)
    def technical_fnz(self, **kw):
        print('kwww', kw)
        assessment = request.env['badminto.assessment'].sudo().browse(
            int(kw.get('assessment')))

        organisation_id = request.env[
            'organisation.organisation'].sudo().search(
            [('partner_id', '=', request.env.user.partner_id.id)])

        fnz_to_fnk_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_to_forehand_technical'))

        fnz_co_fnp_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_forehand_technical'))

        fnz_co_ofcn_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_offensive_technical'))

        fnz_co_fol_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_forehand_offensive_lift'))

        fnz_co_fss_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_forehand_straight_spin'))

        fnz_co_frs_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_forehand_reverse_spin'))

        fnz_co_nb_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_co_net_block'))

        fnz_frs_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_forehand_reverse_spin'))

        fnz_neutralisation_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_neutralisation'))

        fnz_cd_dfcn_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_defensive_forehand_cross_net'))

        fnz_cd_dfl_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_defensive_forehand_lifts'))

        fnz_td_dd_values = organisation_id.technical_configuration_ids.filtered(
            lambda x: x.type == request.env.ref(
                'badminto.fnz_defensive_dive'))

        # if assessment.fnz_to_fnk_grip and assessment.fnz_to_fnk_sp and \
        #         assessment.fnz_to_fnk_bp and assessment.fnz_to_fnk_be and \
        #         assessment.fnz_to_fnk_fs and assessment.service_toi and \
        #         assessment.service_ft:
        #     service_complete = True
        # else:
        #     service_complete = False



