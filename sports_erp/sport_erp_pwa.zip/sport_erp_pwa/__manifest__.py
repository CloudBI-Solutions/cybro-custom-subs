{
    "name": "Sport ERP Progressive Web Application",
    "summary": "Sport ERP Progressive Web Application",
    "version": "15.0.1.0.0",
    "depends": ["base", "sports_erp_dashboard"],
    "data": [
        'views/res_config_settings_views.xml',
        'views/sport_erp_pwa.xml',
    ],
    "installable": True,
}
