from odoo import models, fields


class CalculatedMetric(models.Model):
    _name = 'calculated.metric'

    name = fields.Char(required=True)
    operator = fields.Many2one('calculated.metric.operator')
    number = fields.Integer()
    formula = fields.Char()
    operand_1 = fields.Many2one('calculated.metric')
    operand_2 = fields.Many2one('calculated.metric')
    organisation_id = fields.Many2one('organisation.organisation')
    visualization_configuration_ids = fields.One2many('assessment.visualization.configuration', 'metric_id')

    _sql_constraints = [('name', 'UNIQUE (name)',
                         'You can not have two metric with the same Name !')]


class AssessmentVisualConfiguration(models.Model):
    _name = 'assessment.visualization.configuration'

    start = fields.Integer()
    end = fields.Integer()
    metric_id = fields.Many2one('calculated.metric')
    color = fields.Integer()
    level = fields.Selection([('low', 'Low'), ('medium', 'Medium'),
                              ('high', 'High')])


class CalculatedMetricOperator(models.Model):
    _name = 'calculated.metric.operator'
    _sql_constraints = [
        ('type_unique', 'unique (type)',
         "A Operator of this type already exists."),
    ]

    name = fields.Char('Name', required=1)
    type = fields.Selection([('add', 'Addition'), ('subtract', 'Subtraction'),
                             ('multiply', 'Multiplication'),
                             ('divide', 'Division')],
                            string='Type', default='add')