from odoo import models, fields


class Organisation(models.Model):
    _inherit = 'organisation.organisation'

    lifestyle_assessment_data_id = fields.Many2one('survey.survey')
    sc_assessment_data_id = fields.Many2one('survey.survey')
    mobility_assessment_data_id = fields.Many2one('survey.survey')
    hrv_assessment_data_id = fields.Many2one('survey.survey')
    nutrition_assessment_data_id = fields.Many2one('survey.survey')
    mental_assessment_data_id = fields.Many2one('survey.survey')
    aerobic_assessment_data_id = fields.Many2one('survey.survey')
    anaerobic_assessment_data_id = fields.Many2one('survey.survey')
