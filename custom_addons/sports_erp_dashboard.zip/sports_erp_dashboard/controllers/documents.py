import base64
import json

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, \
    pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class Documents(CustomerPortal):

    @http.route(['/my/documents'], type='http',
                auth='user', website=True)
    def documents_home(self, page=0, search='', **post):
        values = {'is_account': True}
        return request.render(
            'sports_erp_dashboard.documents_template', values)
