odoo.define('sports_erp_dashboard.coach', function (require) {
    "use strict";
    const dom = require('web.dom');
    var publicWidget = require('web.public.widget');
    var PortalSidebar = require('portal.PortalSidebar');
    var utils = require('web.utils');
    var rpc = require('web.rpc');

    $(document).ready(function () {
      $('.sports-erp-dashbaord-select').select2();
    });

    publicWidget.registry.CoachPage = publicWidget.Widget.extend({
        selector: '.js_usermenu',
        events: {
            'click #organisations': '_onChangeOrganisation',
        },
        _onChangeOrganisation: function (ev) {
            utils.set_cookie('select_organisation', ev.currentTarget.value);
            console.log(document.cookie);
            location.reload();
        },
    });
});