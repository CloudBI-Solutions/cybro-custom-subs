from odoo import fields, models


class Partner(models.Model):
    """inherited res partner"""
    _inherit = "res.partner"

    last_name = fields.Char(string='Last Name')

    def name_get(self):
        result = []
        for rec in self:
            if rec.last_name:
                name = rec.name + ' ' + rec.last_name
                result.append((rec.id, name))
            else:
                name = rec.name
                result.append((rec.id, name))
        return result

