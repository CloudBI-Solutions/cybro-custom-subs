import base64
import json

from odoo.addons.http_routing.models.ir_http import slug
from odoo import fields, _
from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, \
    pager as portal_pager
from collections import OrderedDict
from odoo.http import request, route
from datetime import datetime, date
from odoo.addons.website_sale.controllers.main import WebsiteSale
from dateutil.relativedelta import relativedelta


class WebsiteSaleSports(WebsiteSale):
    @http.route(['/shop/confirmation'],
                type='http', auth="public", website=True)
    def payment_confirmation(self, **post):
        response = super(WebsiteSaleSports,
                         self).shop_payment_confirmation(**post)
        print(post, "post")
        order_lines = response.qcontext['order'].order_line
        partner = response.qcontext['order'].partner_id

        if partner:
            line = order_lines.filtered(
                lambda x: x.product_id.organisation_stage_id)
            if line:
                organisation_partner = partner.sudo().copy()
                organisation = request.env[
                    'organisation.organisation'].sudo().search(
                    [('allowed_user_ids', 'in', [request.env.user.id])])
                print(organisation, "organisations")
                # if not organisation:
                request.env['organisation.organisation'].sudo().create({
                    'partner_id': organisation_partner.id,
                    'name': organisation_partner.company_name if organisation_partner.company_name else organisation_partner.name,
                    'stage_id': line.product_id.organisation_stage_id.id,
                })
            return response


class Organisation(CustomerPortal):

    # HOME

    @route(['/my', '/my/home',
            '/my/home/<model("organisation.organisation"):organisation_id>'],
           type='http', auth="user", website=True)
    def home(self, organisation_id=None, **kw):
        print(organisation_id, "organisation")

        values = self._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        selected_organisation = request.httprequest.cookies.get('selected_organisation')
        print(selected_organisation, "cookies")
        if organisation_id:
            organisations = request.env[
                'organisation.organisation'].sudo().search(
                [('partner_id', '=', partner.id),
                 ('id', '!=', organisation_id.id)])
            for org in organisations:
                org.sudo().is_selected_organisation = False
            organisation_id.is_selected_organisation = True
        else:
            organisation = request.env[
                'organisation.organisation'].sudo().search(
                ['|', ('partner_id', '=', partner.id),
                 ('id', '=', selected_organisation)], limit=1)
            print(organisation)
            organisation.is_selected_organisation = True
        if partner.org_group_selection == 'organisation':
            organisation = request.env[
                'organisation.organisation'].sudo().search(
                [('partner_id', '=', partner.id)])
            athletes = organisation.athlete_ids

            values.update({
                'partner': partner,
                # 'athletes': athletes,
                'page_name': 'organisation',
                'is_account': True
            })
            response = request.render(
                "organisation.portal_organisation_dashboard",
                values)
        if partner.org_group_selection == 'parents':
            parent = request.env['organisation.parents'].sudo().search(
                [('partner_id', '=', partner.id)])
            athletes = parent.athlete_ids
            values.update({
                'partner': partner,
                'athletes': athletes,
                'page_name': 'athlete_list',
                'is_account': True
            })
            response = request.render("organisation.portal_athlete_list",
                                      values)
            return response
        if partner.org_group_selection == 'athletes':
            athlete = request.env['organisation.athletes'].sudo().search(
                [('partner_id', '=', partner.id)])
            tasks = athlete.task_ids
            links = request.env['athlete.dashboard.link'].sudo().search([])
            values.update({
                'partner': partner,
                'athlete': athlete,
                'tasks': tasks,
                'links': links,
                'is_account': True
            })
            params = request.env['ir.config_parameter'].sudo()
            athlete_profile = params.get_param('organisation.athlete_profile')
            athlete_booking = params.get_param('organisation.athlete_booking')
            athlete_calendar = params.get_param('organisation.athlete_calendar')
            athlete_products = params.get_param('organisation.athlete_products')
            athlete_forms = params.get_param('organisation.athlete_forms')
            athlete_documents = params.get_param(
                'organisation.athlete_documents')
            athlete_timesheet = params.get_param(
                'organisation.athlete_timesheet')
            athlete_coaches = params.get_param('organisation.athlete_coaches')
            athlete_invoices = params.get_param('organisation.athlete_invoices')
            athlete_parents = params.get_param('organisation.athlete_parents')
            athlete_chat_hub = params.get_param('organisation.athlete_chat_hub')
            athlete_assignments = params.get_param(
                'organisation.athlete_assignments')
            athlete_attendance = params.get_param(
                'organisation.athlete_attendance')
            mobile = params.get_param('organisation.mobile')
            tablet = params.get_param('organisation.tablet')
            desktop = params.get_param('organisation.desktop')
            values.update({
                'athlete_profile': athlete_profile,
                'athlete_booking': athlete_booking,
                'athlete_calendar': athlete_calendar,
                'athlete_products': athlete_products,
                'athlete_forms': athlete_forms,
                'athlete_documents': athlete_documents,
                'athlete_timesheet': athlete_timesheet,
                'athlete_coaches': athlete_coaches,
                'athlete_invoices': athlete_invoices,
                'athlete_parents': athlete_parents,
                'athlete_chat_hub': athlete_chat_hub,
                'athlete_assignments': athlete_assignments,
                'athlete_attendance': athlete_attendance,
                'mobile': mobile,
                'tablet': tablet,
                'desktop': desktop
            })
            response = request.render(
                "organisation.portal_organisation_dashboard", values)
            return response
        if partner.org_group_selection == 'fans':
            fan = request.env['organisation.fans'].sudo().search(
                [('partner_id', '=', partner.id)])
            links = request.env['fan.dashboard.link'].sudo().search([])
            values.update({
                'links': links,
                'partner': partner,
                'fan': fan,
                'is_account': True
            })
            params = request.env['ir.config_parameter'].sudo()
            fan_profile = params.get_param('organisation.fan_profile')
            fan_booking = params.get_param('organisation.fan_booking')
            fan_calendar = params.get_param('organisation.fan_calendar')
            mobile = params.get_param('organisation.mobile')
            tablet = params.get_param('organisation.tablet')
            desktop = params.get_param('organisation.desktop')
            values.update({
                'fan_profile': fan_profile,
                'fan_booking': fan_booking,
                'fan_calendar': fan_calendar,
                'mobile': mobile,
                'tablet': tablet,
                'desktop': desktop,
            })
            response = request.render(
                "organisation.portal_fans_dashboard", values)
            return response
        values.update({
            'partner': partner,
            'is_account': True
        })
        return request.render("sports_erp_dashboard.sports_erp_portal", values)

        # Dashboard

    @route(['/my/settings', '/settings'], type='http', auth='user',
           website=True)
    def settings_dashboard(self):
        """RENDER SETTINGS PAGE TEMPLATE"""
        response = request.render("sports_erp_dashboard.settings_dashboard")
        response.headers['X-Frame-Options'] = 'DENY'
        return response

    @http.route(['/my/invoices', '/my/invoices/page/<int:page>'], type='http',
                auth="user", website=True)
    def portal_my_invoices(self, page=1, date_begin=None, date_end=None,
                           sortby=None, filterby=None, **kw):
        """RENDER INVOICES"""
        if request.env.user.partner_id.org_group_selection == 'organisation':
            partner = request.env.user.partner_id
            values = self._prepare_portal_layout_values()
            organisation = request.env[
                'organisation.organisation'].sudo().search([
                ('partner_id', '=', partner.id)
            ])
            # childs = parent.child_ids
            # child_partners = childs.mapped('partner_id')
            AccountInvoice = request.env['account.move']
            domain = self._get_invoices_domain()
            domain += [(
                'partner_id', '=', organisation.partner_id.id)]
            searchbar_sortings = {
                'date': {'label': _('Date'), 'order': 'invoice_date desc'},
                'duedate': {'label': _('Due Date'),
                            'order': 'invoice_date_due desc'},
                'name': {'label': _('Reference'), 'order': 'name desc'},
                'state': {'label': _('Status'), 'order': 'state'},
            }
            # default sort by order
            if not sortby:
                sortby = 'date'
            order = searchbar_sortings[sortby]['order']

            searchbar_filters = {
                'all': {'label': _('All'), 'domain': []},
                'invoices': {'label': _('Invoices'), 'domain': [
                    ('move_type', '=', ('out_invoice', 'out_refund'))]},
                'bills': {'label': _('Bills'), 'domain': [
                    ('move_type', '=', ('in_invoice', 'in_refund'))]},
            }
            # default filter by value
            if not filterby:
                filterby = 'all'
            domain += searchbar_filters[filterby]['domain']

            if date_begin and date_end:
                domain += [('create_date', '>', date_begin),
                           ('create_date', '<=', date_end)]

            # count for pager
            invoice_count = AccountInvoice.sudo().search_count(domain)
            # pager
            pager = portal_pager(
                url="/my/invoices",
                url_args={'date_begin': date_begin, 'date_end': date_end,
                          'sortby': sortby},
                total=invoice_count,
                page=page,
                step=self._items_per_page
            )
            # content according to pager and archive selected
            invoices = AccountInvoice.sudo().search(
                domain, order=order,
                limit=self._items_per_page,
                offset=pager['offset'])
            request.session['my_invoices_history'] = invoices.ids[:100]
            values.update({
                'date': date_begin,
                'invoices': invoices,
                'page_name': 'invoice',
                'pager': pager,
                'default_url': '/my/invoices',
                'searchbar_sortings': searchbar_sortings,
                'sortby': sortby,
                'searchbar_filters': OrderedDict(
                    sorted(searchbar_filters.items())),
                'filterby': filterby,
            })
            return request.render("account.portal_my_invoices", values)

        # elif request.env.user.partner_id.is_child:
        #     child_partner = request.env.user.partner_id
        #     child = request.env['paceflow.child'].search([
        #         ('partner_id', '=', child_partner.id)
        #     ])
        #     difference = relativedelta(date.today(), child.dob)
        #     if int(difference.years) >= 18:
        #         values = self._prepare_portal_layout_values()
        #         AccountInvoice = request.env['account.move']
        #         domain = self._get_invoices_domain()
        #         domain += [(
        #             'partner_id', '=', child_partner.id)]
        #         searchbar_sortings = {
        #             'date': {'label': _('Date'), 'order': 'invoice_date desc'},
        #             'duedate': {'label': _('Due Date'),
        #                         'order': 'invoice_date_due desc'},
        #             'name': {'label': _('Reference'), 'order': 'name desc'},
        #             'state': {'label': _('Status'), 'order': 'state'},
        #         }
        #         # default sort by order
        #         if not sortby:
        #             sortby = 'date'
        #         order = searchbar_sortings[sortby]['order']
        #
        #         searchbar_filters = {
        #             'all': {'label': _('All'), 'domain': []},
        #             'invoices': {'label': _('Invoices'), 'domain': [
        #                 ('move_type', '=', ('out_invoice', 'out_refund'))]},
        #             'bills': {'label': _('Bills'), 'domain': [
        #                 ('move_type', '=', ('in_invoice', 'in_refund'))]},
        #         }
        #         # default filter by value
        #         if not filterby:
        #             filterby = 'all'
        #         domain += searchbar_filters[filterby]['domain']
        #
        #         if date_begin and date_end:
        #             domain += [('create_date', '>', date_begin),
        #                        ('create_date', '<=', date_end)]
        #
        #         # count for pager
        #         invoice_count = AccountInvoice.sudo().search_count(domain)
        #         # pager
        #         pager = portal_pager(
        #             url="/my/invoices",
        #             url_args={'date_begin': date_begin, 'date_end': date_end,
        #                       'sortby': sortby},
        #             total=invoice_count,
        #             page=page,
        #             step=self._items_per_page
        #         )
        #         # content according to pager and archive selected
        #         invoices = AccountInvoice.sudo().search(
        #             domain, order=order,
        #             limit=self._items_per_page,
        #             offset=pager['offset'])
        #         request.session['my_invoices_history'] = invoices.ids[:100]
        #         values.update({
        #             'date': date_begin,
        #             'invoices': invoices,
        #             'page_name': 'invoice',
        #             'pager': pager,
        #             'default_url': '/my/invoices',
        #             'searchbar_sortings': searchbar_sortings,
        #             'sortby': sortby,
        #             'searchbar_filters': OrderedDict(
        #                 sorted(searchbar_filters.items())),
        #             'filterby': filterby,
        #         })
        #         return request.render("account.portal_my_invoices", values)
        #     else:
        #         response = request.render("paceflow.portal_forbidden")
        #         response.headers['X-Frame-Options'] = 'DENY'
        #         return response
        #
        # elif request.env.user.partner_id.is_client:
        #     coach_partner = request.env.user.partner_id
        #     values = self._prepare_portal_layout_values()
        #     coach = request.env['paceflow.client'].sudo().search([
        #         ('partner_id', '=', coach_partner.id)
        #     ])
        #     childs = coach.child_ids
        #     child_partners = childs.mapped('partner_id')
        #     parents = request.env['paceflow.parents'].sudo().search([
        #         ('created_coach', '=', coach.id)
        #     ])
        #     parent_partners = parents.mapped('partner_id')
        #     AccountInvoice = request.env['account.move']
        #     domain = self._get_invoices_domain()
        #     domain += [
        #         ('partner_id', 'in',
        #          coach_partner.ids + child_partners.ids + parent_partners.ids)]
        #     searchbar_sortings = {
        #         'date': {'label': _('Date'), 'order': 'invoice_date desc'},
        #         'duedate': {'label': _('Due Date'),
        #                     'order': 'invoice_date_due desc'},
        #         'name': {'label': _('Reference'), 'order': 'name desc'},
        #         'state': {'label': _('Status'), 'order': 'state'},
        #     }
        #     # default sort by order
        #     if not sortby:
        #         sortby = 'date'
        #     order = searchbar_sortings[sortby]['order']
        #
        #     searchbar_filters = {
        #         'all': {'label': _('All'), 'domain': []},
        #         'invoices': {'label': _('Invoices'), 'domain': [
        #             ('move_type', '=', ('out_invoice', 'out_refund'))]},
        #         'bills': {'label': _('Bills'), 'domain': [
        #             ('move_type', '=', ('in_invoice', 'in_refund'))]},
        #     }
        #     # default filter by value
        #     if not filterby:
        #         filterby = 'all'
        #     domain += searchbar_filters[filterby]['domain']
        #
        #     if date_begin and date_end:
        #         domain += [('create_date', '>', date_begin),
        #                    ('create_date', '<=', date_end)]
        #
        #     # count for pager
        #     invoice_count = AccountInvoice.sudo().search_count(domain)
        #     # pager
        #     pager = portal_pager(
        #         url="/my/invoices",
        #         url_args={'date_begin': date_begin, 'date_end': date_end,
        #                   'sortby': sortby},
        #         total=invoice_count,
        #         page=page,
        #         step=self._items_per_page
        #     )
        #     # content according to pager and archive selected
        #     invoices = AccountInvoice.sudo().search(domain, order=order,
        #                                             limit=self._items_per_page,
        #                                             offset=pager['offset'])
        #     request.session['my_invoices_history'] = invoices.ids[:100]
        #     values.update({
        #         'date': date_begin,
        #         'invoices': invoices,
        #         'page_name': 'invoice',
        #         'pager': pager,
        #         'default_url': '/my/invoices',
        #         'searchbar_sortings': searchbar_sortings,
        #         'sortby': sortby,
        #         'searchbar_filters': OrderedDict(
        #             sorted(searchbar_filters.items())),
        #         'filterby': filterby,
        #     })
        #     return request.render("account.portal_my_invoices", values)

    @route(['/my/dashboard'], type='http', auth="user", website=True)
    def my_dashboard(self):
        login_user = request.env.user.partner_id
        organisation = request.env['organisation.organisation'].sudo().search(
            [('partner_id', '=', login_user.id),
             ('is_selected_organisation', '=', True)], limit=1)
        values = {
            'user': login_user,
            'is_account': True,
            'organisation': organisation,
        }
        return request.render("sports_erp_dashboard.sports_erp_dashboard",
                              values)

    # COACHES
    @http.route(['/my/coaches', '/my/coaches/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_coaches(self, page=0, search='', **post):
        domain = []
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=', request.httprequest.cookies.get('selected_organisation'))], limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        print(domain, "domain")
        coaches = request.env['organisation.coaches'].sudo().search(domain)
        total = len(coaches)
        pager = request.website.pager(
            url='/my/coaches',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        coaches = coaches[offset: offset + 5]
        values = {
            'search': search,
            'coaches': coaches,
            'pager': pager,
            'is_account': True,
            'total_coaches': request.env['organisation.coaches'].sudo().search(
                [])
        }
        return request.render('sports_erp_dashboard.coach_dashboard_template',
                              values)

    @http.route('/create/coach', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_coach(self, **post):
        if post:
            coach_partner = request.env['res.partner'].sudo().create({
                'name': post.get('coach_name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            athlete_ids = list(
                map(int, request.httprequest.form.getlist('athletes')))
            group_ids = list(
                map(int, request.httprequest.form.getlist('groups')))
            discipline_ids = list(
                map(int, request.httprequest.form.getlist('disciplines')))
            document_ids = list(
                map(int, request.httprequest.form.getlist('documents')))
            values = {
                'partner_id': coach_partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'create_booking': post.get('booking'),
                'price_o2o': post.get('onetoprice'),
                'price_team': post.get('teamprice'),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
                'group_ids': [(4, group) for group in group_ids],
                'discipline_ids': [(4, discipline) for discipline in
                                   discipline_ids],
                'athlete_ids': [(4, athlete) for athlete in athlete_ids],
                'document_ids': [(4, document) for document in document_ids],
            }
            coach = request.env['organisation.coaches'].sudo().create(values)
            coach.partner_id.write({
                'create_booking': True if post.get(
                    'booking') == 'on' else False,
                'image_1920': base64.b64encode(
                    post.get('photo').read()) if post.get('photo') else False
            })
            return request.redirect('/my/coaches')

    @http.route('/remove/coach/<model("organisation.coaches"):coach_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_coach(self, coach_id=None):
        if coach_id:
            coach_id.sudo().unlink()
        return request.redirect('/my/coaches')

    @http.route('/my/coach/<model("organisation.coaches"):coach_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def coach_details(self, coach_id=None):
        values = {
            'coach': coach_id,
            'is_account': True
        }
        return request.render(
            'sports_erp_dashboard.coach_dashboard_details_template', values)

    @http.route('/update',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def update_coach(self, **post):
        print(post, "post")
        tag_ids = list(
            map(int, request.httprequest.form.getlist('tags')))
        organisation_ids = list(
            map(int, request.httprequest.form.getlist('organisations')))
        athlete_ids = list(
            map(int, request.httprequest.form.getlist('athletes')))
        group_ids = list(
            map(int, request.httprequest.form.getlist('groups')))
        document_ids = list(
            map(int, request.httprequest.form.getlist('documents')))
        discipline_ids = list(
            map(int, request.httprequest.form.getlist('disciplines')))

        values = {
            'name': post.get('name'),
            'email': post.get('email'),
            'phone': post.get('phone'),
            'discipline_ids': [(4, discipline) for discipline in
                               discipline_ids],
            'price_o2o': post.get('onetoprice'),
            'price_team': post.get('teamprice'),
            'athlete_ids': [(4, athlete) for athlete in athlete_ids],
            'tag_ids': [(4, tag) for tag in tag_ids],
            'organisation_ids': [(4, organisation) for organisation in
                                 organisation_ids],
            'group_ids': [(4, group) for group in group_ids],
            'document_ids': [(4, document) for document in document_ids],
        }
        coach = request.env['organisation.coaches'].sudo().browse(
            int(post.get('coach')))
        if coach:
            coach.sudo().write({
                'discipline_ids': [(5, 0, 0)],
                'athlete_ids': [(5, 0, 0)],
                'tag_ids': [(5, 0, 0)],
                'organisation_ids': [(5, 0, 0)],
                'group_ids': [(5, 0, 0)],
                'document_ids': [(5, 0, 0)],
            })
            coach.partner_id.sudo().write({
                'name': post.get('name'),
                'email': post.get('email'),
                'phone': post.get('phone'),
                'height': post.get('height'),
                'weight': post.get('weight'),
                'image_1920': base64.b64encode(
                    post.get('photo').read()) if post.get('photo') else False
            })
        coach.sudo().write(values)
        return request.redirect('/my/coach/%s' % coach.id)

    @http.route(['/my/athletes/home', '/my/athletes/home/page/<int:page>'],
                type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_athletes_home(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        athletes = request.env['organisation.athletes'].sudo().search(domain)
        total = athletes.sudo().search_count([])
        pager = request.website.pager(
            url='/my/athletes/home',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        athletes = athletes[offset: offset + 5]
        return request.render('sports_erp_dashboard.athlete_dashboard_template',
                              {
                                  'search': search,
                                  'athletes': athletes,
                                  'pager': pager,
                                  'is_account': True,
                                  'total_athletes': request.env[
                                      'organisation.athletes'].sudo().search(
                                      [])
                              })

    @http.route('/create/athlete', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_athlete(self, **post):
        if post:
            print('post', post)
            athlete_partner = request.env['res.partner'].sudo().create({
                'name': post.get('athlete_name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            parent_ids = list(
                map(int, request.httprequest.form.getlist('parents')))
            coach_ids = list(
                map(int, request.httprequest.form.getlist('coaches')))
            group_ids = list(
                map(int, request.httprequest.form.getlist('groups')))
            product_ids = list(
                map(int, request.httprequest.form.getlist('products')))
            print(product_ids, "ids")
            discipline_ids = list(
                map(int, request.httprequest.form.getlist('disciplines')))
            values = {
                'partner_id': athlete_partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'member_id': post.get('member_id'),
                'dob': post.get('dob'),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, organisation) for organisation in
                                     organisation_ids],
                'group_ids': [(4, group) for group in group_ids],
                'parent_ids': [(4, parent) for parent in parent_ids],
                'product_ids': [(4, product) for product in product_ids],
                'coach_ids': [(4, coach) for coach in coach_ids],
                'discipline_ids': [(4, discipline) for discipline in
                                   discipline_ids],
            }
            athlete = request.env['organisation.athletes'].sudo().create(values)
            athlete.partner_id.write({
                'create_booking': True if post.get(
                    'booking') == 'on' else False,
                'image_1920': base64.b64encode(
                    post.get('photo').read()) if post.get('photo') else False
            })
            return request.redirect('/my/athletes/home')

    @http.route('/remove/<model("organisation.athletes"):athlete_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_athlete(self, athlete_id=None):
        if athlete_id:
            athlete_id.sudo().unlink()
        return request.redirect('/my/athletes/home')

    @http.route('/my/athlete/<model("organisation.athletes"):athlete_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='GET')
    def athlete_details(self, athlete_id=None):
        values = {
            'athlete': athlete_id,
            'is_account': True
        }
        return request.render(
            'sports_erp_dashboard.athlete_dashboard_details_template', values)

    @http.route('/update/athlete',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def update_athlete(self, **post):
        print(post, "posttttt")
        tag_ids = list(
            map(int, request.httprequest.form.getlist('tags')))
        organisation_ids = list(
            map(int, request.httprequest.form.getlist('organisations')))
        parent_ids = list(
            map(int, request.httprequest.form.getlist('parents')))
        coach_ids = list(
            map(int, request.httprequest.form.getlist('coaches')))
        group_ids = list(
            map(int, request.httprequest.form.getlist('groups')))
        product_ids = list(
            map(int, request.httprequest.form.getlist('products')))
        discipline_ids = list(
            map(int, request.httprequest.form.getlist('disciplines')))

        values = {
            'name': post.get('name'),
            'email': post.get('email'),
            'phone': post.get('phone'),
            'member_id': post.get('member_id'),
            'discipline_ids': [(4, discipline) for discipline in
                               discipline_ids],
            'parent_ids': [(4, parent) for parent in parent_ids],
            'tag_ids': [(4, tag) for tag in tag_ids],
            'organisation_ids': [(4, organisation) for organisation in
                                 organisation_ids],
            'group_ids': [(4, group) for group in group_ids],
            'product_ids': [(4, product) for product in product_ids],
            'coach_ids': [(4, coach) for coach in coach_ids],
        }
        athlete = request.env['organisation.athletes'].sudo().browse(
            int(post.get('athlete')))
        print(post, "athlete")
        if athlete:
            athlete.sudo().write({
                'discipline_ids': [(5, 0, 0)],
                'parent_ids': [(5, 0, 0)],
                'tag_ids': [(5, 0, 0)],
                'organisation_ids': [(5, 0, 0)],
                'group_ids': [(5, 0, 0)],
                'product_ids': [(5, 0, 0)],
                'coach_ids': [(5, 0, 0)],
            })
            athlete.partner_id.sudo().write({
                'name': post.get('name'),
                'email': post.get('email'),
                'phone': post.get('phone'),
                'height': post.get('height'),
                'weight': post.get('weight'),
                'image_1920': base64.b64encode(
                    post.get('photo').read()) if post.get('photo') else False
            })
            athlete.sudo().write(values)
        return request.redirect('/my/athlete/%s' % athlete.id)

    # PARENTS

    @http.route(['/my/parents', '/my/parents/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_parents(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        parents = request.env['organisation.parents'].sudo().search(domain)
        total = parents.sudo().search_count([])
        pager = request.website.pager(
            url='/my/parents',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        parents = parents[offset: offset + 5]
        print(pager, "pager")
        return request.render('sports_erp_dashboard.parents_dashboard_template',
                              {
                                  'search': search,
                                  'parents': parents,
                                  'total_parents': request.env[
                                      'organisation.parents'].sudo().search([]),
                                  'pager': pager,
                                  'is_account': True
                              })

    @http.route('/create/parent', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_parent(self, **post):
        if post:
            print(post, "post....")
            parent_partner = request.env['res.partner'].sudo().create({
                'name': post.get('parent_name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            athlete_ids = list(
                map(int, request.httprequest.form.getlist('athletes')))
            values = {
                'partner_id': parent_partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
                'athlete_ids': [(4, athlete) for athlete in athlete_ids],
            }
            if post.get('responsible'):
                values.update({
                    'responsible_user_id': int(post.get('responsible')),
                })
            parent = request.env['organisation.parents'].sudo().create(values)
            parent.partner_id.write({
                'create_booking': True if post.get(
                    'booking') == 'on' else False,
            })
            return request.redirect('/my/parents')

    @http.route('/remove/parent/<model("organisation.parents"):parent_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_parent(self, parent_id=None):
        if parent_id:
            parent_id.sudo().unlink()
        return request.redirect('/my/parents')

    @http.route('/my/parent/<model("organisation.parents"):parent_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def parent_details(self, parent_id=None):
        values = {
            'parent': parent_id,
            'is_account': True
        }
        return request.render(
            'sports_erp_dashboard.parent_dashboard_details_template', values)

    @http.route(['/my/groups', '/my/groups/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_groups(self, page=0, search='', **post):
        print("self....", search)
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        groups = request.env['athlete.groups'].sudo().search(domain)
        total = groups.sudo().search_count([])
        pager = request.website.pager(
            url='/my/groups',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        groups = groups[offset: offset + 5]
        print(groups, "pager")
        return request.render('sports_erp_dashboard.groups_template',
                              {
                                  'search': search,
                                  'groups': groups,
                                  'pager': pager,
                                  'is_account': True
                              })

    @http.route('/create/group', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_group(self, **post):
        if post:
            print(post, "post....")
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            athlete_ids = list(
                map(int, request.httprequest.form.getlist('athletes')))
            document_ids = list(
                map(int, request.httprequest.form.getlist('documents')))
            partner = request.env['res.partner'].sudo().create({
                'name': post.get('name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            values = {
                'partner_id': partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'responsible_user_id': int(post.get('responsible_user')),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
                'athlete_ids': [(4, athlete) for athlete in athlete_ids],
                'document_ids': [(4, document) for document in document_ids],
            }
            group = request.env['athlete.groups'].sudo().create(values)

            return request.redirect('/my/groups')

    @http.route('/remove/group/<model("athlete.groups"):group_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_group(self, group_id=None):
        if group_id:
            group_id.sudo().unlink()
        return request.redirect('/my/groups')

    @http.route('/group/<model("athlete.groups"):group_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def group_details(self, group_id=None):
        values = {
            'group': group_id,
            'is_account': True
        }
        return request.render(
            'sports_erp_dashboard.group_dashboard_details_template', values)

    @http.route('/update/group',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def update_group(self, **post):
        print(post, "post")
        values = {
            'name': post.get('name'),
            'email': post.get('email'),
            'phone': post.get('phone')
        }
        print(post.get('group'))
        group = request.env['athlete.groups'].sudo().browse(
            int(post.get('group')))
        group.sudo().write(values)
        return request.redirect('/group/%s' % group.id)

    @http.route(['/my/disciplines', '/my/disciplines/page/<int:page>'],
                type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_disciplines(self, page=0, search='', **post):
        print("self....", search)
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        disciplines = request.env['organisation.discipline'].sudo().search(
            domain)
        total = disciplines.sudo().search_count([])
        pager = request.website.pager(
            url='/my/disciplines',
            total=total,
            page=page,
            step=5,
        )
        offset = pager['offset']
        disciplines = disciplines[offset: offset + 5]
        return request.render('sports_erp_dashboard.discipline_template',
                              {
                                  'search': search,
                                  'disciplines': disciplines,
                                  'pager': pager,
                                  'is_account': True
                              })

    @http.route(['/my/discipline_details/<int:discipline_id>'], type='http',
                auth='user', website=True)
    def discipline_details(self, **kwargs):
        discipline = request.env['organisation.discipline'].sudo().browse(
            kwargs.get('discipline_id'))
        return request.render(
            'sports_erp_dashboard.discipline_details_template',
            {'is_account': True,
             'discipline': discipline,
             'res_users': request.env[
                 'res.users'].sudo().search([]),
             'tags': request.env['venues.tags'].sudo().search(
                 [
                     ('id', 'not in', discipline.tag_ids.ids)
                 ]),
             'organisations': request.env[
                 'organisation.organisation'].sudo().search([
                 ('id', 'not in', discipline.organisation_ids.ids)
             ])
             })

    @http.route(['/create/discipline'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def create_discipline(self, **post):
        if post:
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            partner = request.env['res.partner'].sudo().create({
                'name': post.get('name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            values = {
                'partner_id': partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                # 'date': post.get('date'),
                # 'responsible_user_id': int(post.get('responsible_user')),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
            }
            request.env['organisation.discipline'].sudo().create(values)
            return request.redirect('/my/venues')

    @http.route(['/remove/discipline/<int:discipline_id>'], type='http',
                auth='public', csrf=False, website=True)
    def delete_discipline(self, **post):
        request.env['organisation.discipline'].sudo().browse(
            int(post.get('discipline_id'))).unlink()
        return request.redirect('/my/disciplines')

    @http.route(['/my/update_discipline'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_discipline(self, **post):
        venue = request.env[
            'organisation.discipline'].sudo().browse(
            int(post.get('discipline_id')))
        venue.sudo().write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'date': post.get('date'),
            'email': post.get('email'),
            'responsible_user_id': int(
                post.get('responsible_user')) if post.get(
                'responsible_user') else None,
        })
        venue.sudo().partner_id.write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'email': post.get('email'),
        })
        venue.sudo().write({
            'tag_ids': [(5, 0, 0)],
            'organisation_ids': [(5, 0, 0)]
        })
        tag_ids = list(
            map(int, request.httprequest.form.getlist('tags')))
        if tag_ids:
            venue.sudo().write({
                'tag_ids': [(4, tag) for tag in tag_ids]
            })
        org_ids = list(
            map(int, request.httprequest.form.getlist('organisation')))
        if org_ids:
            venue.sudo().write({
                'organisation_ids': [(4, org) for org in org_ids]
            })
        return request.redirect('/my/venue_details/%s' % venue.id)

    @http.route(['/my/venues', '/my/venues/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def my_venues(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_ids', 'in', [organisation.id]))
        venues = request.env['organisation.venues'].sudo().search(domain)
        total = len(venues)
        pager = request.website.pager(
            url='/my/venues',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        venues = venues[offset: offset + 6]
        values = {
            'search': search,
            'venues': venues,
            'pager': pager,
            'is_account': True,
            'total_venues': request.env['organisation.venues'].sudo().search(
                []),
            'countries': request.env[
                'res.country'].sudo().search([]),
            'states': request.env[
                'res.country.state'].sudo().search([]),
        }
        return request.render('sports_erp_dashboard.venues_template',
                              values)

    @http.route(['/my/venue_details/<int:venue_id>'], type='http',
                auth='user', website=True)
    def venue_details(self, **kwargs):
        venue = request.env['organisation.venues'].sudo().browse(
            kwargs.get('venue_id'))
        return request.render('sports_erp_dashboard.venue_details_template',
                              {'is_account': True,
                               'venue': venue,
                               'res_users': request.env[
                                   'res.users'].sudo().search([]),
                               'tags': request.env['venues.tags'].sudo().search(
                                   [
                                       ('id', 'not in', venue.tag_ids.ids)
                                   ]),
                               'organisations': request.env[
                                   'organisation.organisation'].sudo().search([
                                   ('id', 'not in', venue.organisation_ids.ids)
                               ]),
                               'states': request.env[
                                   'res.country.state'].sudo().search([
                                   ('id', '!=', venue.partner_id.state_id.id)
                               ]),
                               'countries': request.env[
                                   'res.country'].sudo().search([
                                   ('id', '!=', venue.partner_id.country_id.id)
                               ]),
                               })

    @http.route(['/create/venue'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def create_venue(self, **post):
        if post:
            venue_partner = request.env['res.partner'].sudo().create({
                'name': post.get('venue_name'),
                'email': post.get('email'),
                'phone': post.get('phone'),
                'street': post.get('street_name'),
                'city': post.get('city_name'),
                'state_id': int(post.get('state_id')),
                'zip': post.get('zip_code'),
                'country_id': int(post.get('country_id'))
            })
            print('venue', venue_partner)
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            organisation_ids = list(
                map(int, request.httprequest.form.getlist('organisations')))
            values = {
                'partner_id': venue_partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'date': post.get('date'),
                'responsible_user_id': int(post.get('responsible_user')),
                'tag_ids': [(4, tag) for tag in tag_ids],
                'organisation_ids': [(4, org) for org in organisation_ids],
            }
            request.env['organisation.venues'].sudo().create(values)
            return request.redirect('/my/venues')

    @http.route(['/my/delete_venue/<int:venue_id>'], type='http',
                auth='public', csrf=False, website=True)
    def delete_venue(self, **post):
        request.env['organisation.venues'].sudo().browse(
            int(post.get('venue_id'))).unlink()
        return request.redirect('/my/venues')

    @http.route(['/my/update_venues'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_venue(self, **post):
        venue = request.env[
            'organisation.venues'].sudo().browse(int(post.get('venue_id')))
        venue.sudo().write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'date': post.get('date'),
            'email': post.get('email'),
            'responsible_user_id': int(
                post.get('responsible_user')) if post.get(
                'responsible_user') else None,
        })
        venue.sudo().partner_id.write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'email': post.get('email'),
            'street': post.get('street_name'),
            'city': post.get('city_name'),
            'state_id': int(post.get('state_id')),
            'zip': post.get('zip_code'),
            'country_id': int(post.get('country_id')),
        })
        venue.sudo().write({
            'tag_ids': [(5, 0, 0)],
            'organisation_ids': [(5, 0, 0)]
        })
        tag_ids = list(
            map(int, request.httprequest.form.getlist('tags')))
        if tag_ids:
            venue.sudo().write({
                'tag_ids': [(4, tag) for tag in tag_ids]
            })
        org_ids = list(
            map(int, request.httprequest.form.getlist('organisation')))
        if org_ids:
            venue.sudo().write({
                'organisation_ids': [(4, org) for org in org_ids]
            })
        return request.redirect('/my/venue_details/%s' % venue.id)

    @http.route(['/my/fans', '/my/fans/page/<int:page>'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def fans(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             '|', ('is_selected_organisation', '=', True),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        if organisation:
            domain.append(('organisation_id', 'in', [organisation.id]))
        fans = request.env['organisation.fans'].sudo().search(domain)
        total = len(fans)
        pager = request.website.pager(
            url='/my/fans',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        fans = fans[offset: offset + 6]
        values = {
            'search': search,
            'fans': fans,
            'pager': pager,
            'is_account': True,
            'total_fans': request.env['organisation.fans'].sudo().search(
                [])
        }
        return request.render('sports_erp_dashboard.fans_template',
                              values)

    @http.route(['/create/fan'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def create_fan(self, **post):
        if post:
            fan_partner = request.env['res.partner'].sudo().create({
                'name': post.get('fan_name'),
                'last_name': post.get('last_name'),
                'email': post.get('email'),
                'phone': post.get('phone')
            })
            tag_ids = list(
                map(int, request.httprequest.form.getlist('tags')))
            values = {
                'partner_id': fan_partner.id,
                'phone': post.get('phone'),
                'email': post.get('email'),
                'organisation_id': post.get('organisations'),
                'tag_ids': [(4, tag) for tag in tag_ids],
            }
            request.env['organisation.fans'].sudo().create(values)
            fan_partner.write({
                'create_booking': True if post.get(
                    'booking') == 'on' else False
            })
            return request.redirect('/my/fans')

    @http.route(['/my/delete_fan/<int:fan_id>'], type='http',
                auth='public', csrf=False, website=True)
    def delete_fan(self, **post):
        request.env['organisation.fans'].sudo().browse(
            int(post.get('fan_id'))).unlink()
        return request.redirect('/my/fans')

    @http.route(['/my/fan_details/<int:fan_id>'], type='http',
                auth='user', website=True)
    def fan_details(self, **kwargs):
        fan = request.env['organisation.fans'].sudo().browse(
            kwargs.get('fan_id'))
        return request.render('sports_erp_dashboard.fan_details_template',
                              {'is_account': True,
                               'fan': fan,
                               'res_users': request.env[
                                   'res.users'].sudo().search([]),
                               'tags': request.env['fans.tags'].sudo().search(
                                   [('id', 'not in', fan.tag_ids.ids)]),
                               'organisations': request.env[
                                   'organisation.organisation'].sudo().search(
                                   [('id', '!=', fan.organisation_id.id)]),
                               })

    @http.route(['/my/update_fan'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_fan(self, **post):
        print("post", post)
        fan = request.env[
            'organisation.fans'].sudo().browse(int(post.get('fan_id')))
        fan.sudo().write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'email': post.get('email'),
            'organisation_id': int(
                post.get('organisation')) if post.get(
                'organisation') else None,
        })
        fan.sudo().partner_id.write({
            'name': post.get('name'),
            'phone': post.get('phone'),
            'email': post.get('email'),
        })
        fan.sudo().write({
            'tag_ids': [(5, 0, 0)],
        })
        tag_ids = list(
            map(int, request.httprequest.form.getlist('tags')))
        if tag_ids:
            fan.sudo().write({
                'tag_ids': [(4, tag) for tag in tag_ids]
            })
        return request.redirect('/my/fan_details/%s' % fan.id)

    @http.route('/my/update_subscription',
                type='http',
                auth='user', website=True, methods=['POST', 'GET'])
    def update_subscription(self, **post):
        print("pos", post)
        tax_id = list(
            map(int, request.httprequest.form.getlist('taxes')))
        next_payment = post.get('next_payment').replace("T", " ")
        print('nex', next_payment)
        subscription = request.env['subscription.subscription'].browse(
            int(post.get('subscription_id'))
        )
        values = {
            'active': True if post.get(
                'active_subscription') == 'on' else False,
            'contract_id': int(post.get('contract')),
            'customer_name': int(post.get('customer')),
            'customer_billing_address': int(post.get('billing_address')),
            'company_id': int(post.get('company_id')),
            'product_id': int(post.get('product')),
            'quantity': float(post.get('quantity')),
            'sub_plan_id': int(post.get('plan')),
            'duration': int(post.get('duration')),
            'unit': post.get('duration_type'),
            'trial_period': True if post.get(
                'has_trial') == 'on' else False,
            'trial_duration': int(post.get('trial_duration')),
            'trial_duration_unit': post.get('trial_duration_type'),
            'price': float(post.get('price')),
            'start_date': post.get('start_date'),
            'end_date': post.get('end_date') if post.get(
                'end_date') else None,
            'num_billing_cycle': int(post.get('num_billing_cycle')),
            'source': post.get('source'),
            'so_origin': int(post.get('so_origin')) if post.get(
                'so_origin') else None,
            'subscription_ref': post.get('ref'),
            'project_id': int(post.get('project')) if post.get(
                'project') else None,
            'next_payment_date': next_payment,
        }
        subscription.sudo().write(values)
        subscription.sudo().write({
            'tax_id': [(5, 0, 0)],
        })
        if tax_id:
            subscription.sudo().write({
                'tax_id': [(4, tax) for tax in tax_id]
            })
        if int(post.get('state_subscription')):
            if int(post.get('state_subscription')) == request.env.ref(
                    'subscription_management.stage_active').id:
                subscription.get_confirm_subscription()
            if int(post.get('state_subscription')) == request.env.ref(
                    'subscription_management.stage_frozen').id:
                subscription.get_frozen_subscription()
            if int(post.get('state_subscription')) == request.env.ref(
                    'subscription_management.stage_doubtful').id:
                subscription.get_doubtful_subscription()
            if int(post.get('state_subscription')) == request.env.ref(
                    'subscription_management.stage_not_renewing').id:
                subscription.get_not_renewing_subscription()
            if int(post.get('state_subscription')) == request.env.ref(
                    'subscription_management.stage_terminated').id:
                subscription.get_terminated_subscription()

        return request.redirect('/my/subscription_details/%s' % subscription.id)

    @http.route('/my/subscription_details/<int:subscription_id>',
                type='http',
                auth='user', website=True)
    def subscription_details(self, **kwargs):
        print('kwar', kwargs)
        subscription = request.env[
            'subscription.subscription'].browse(kwargs.get('subscription_id'))
        print("subs", subscription.next_payment_date)
        values = {
            'subscription': subscription,
            'is_account': True,
            'stages': request.env['subscription.stage'].search([
                ('id', '!=', subscription.stage_id.id)
            ]),
            'contracts': request.env['subscription.contract'].search([
                ('id', '!=', subscription.contract_id.id)
            ]),
            'customers': request.env['res.partner'].search([
                ('id', '!=', subscription.customer_name.id)
            ]),
            'billing_address': request.env['res.partner'].search([
                ('id', '!=', subscription.customer_billing_address.id)
            ]),
            'products': request.env['product.product'].search([
                ('id', '!=', subscription.product_id.id),
                ('sale_ok', '=', True),
                ('activate_subscription', '=', True)
            ]),
            'taxes': request.env['account.tax'].search([
                ('id', 'not in', subscription.tax_id.ids)]),
            'plans': request.env['subscription.plan'].search([
                ('id', '!=', subscription.sub_plan_id.id)
            ]),
            'sos': request.env['sale.order'].search([
                ('id', '!=', subscription.so_origin.id)
            ]),
            'projects': request.env['project.project'].search([
                ('id', '!=', subscription.project_id.id)
            ]),
        }
        return request.render(
            'sports_erp_dashboard.subscription_details', values)

    @http.route(['/my/subscriptions'], type='http',
                auth='user', website=True)
    def subscription_home(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        subscription = request.env['subscription.subscription'].sudo().search(
            domain)
        total = len(subscription)
        pager = request.website.pager(
            url='/my/subscriptions',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        subscription = subscription[offset: offset + 6]
        values = {
            'search': search,
            'subscription_plans': subscription,
            'pager': pager,
            'is_account': True,
            'total_subscriptions': request.env[
                'subscription.subscription'].sudo().search(
                [])
        }
        return request.render(
            'sports_erp_dashboard.subscription_template', values)

    @http.route(['/create/subscription'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def create_subscription(self, **post):
        tax_ids = list(
            map(int, request.httprequest.form.getlist('subscription_taxes')))
        values = {
            'active': True if post.get(
                'active_subscription') == 'on' else False,
            'contract_id': int(post.get('subscription_contracts')),
            'customer_name': int(post.get('subscription_customers')),
            'customer_billing_address': int(post.get('subscription_address')),
            'company_id': int(post.get('subscription_company')),
            'product_id': int(post.get('subscription_products')),
            'tax_id': [(4, tax) for tax in tax_ids],
            'quantity': float(post.get('quantity')),
            'sub_plan_id': int(post.get('subscription_plans')),
            'price': float(post.get('price')),
            'duration': int(post.get('recurrency')),
            'unit': post.get('recurrency_duration_type'),
            'start_date': post.get('start_date'),
            'end_date': post.get('end_date'),
            'num_billing_cycle': int(post.get('billing_cycle')),
            'source': post.get('source'),
            'subscription_ref': post.get('subscription_ref'),
            'project_id': int(post.get('project_id')),
            'next_payment_date': post.get('next_payment')

        }
        if post.get('has_trial_period') == 'on':
            values.update({
                'trial_period': True,
                'trial_duration': int(post.get('trial_duration')),
                'trial_duration_unit': post.get('trial_duration_type')
            })
        subscription = request.env['subscription.subscription'].create(values)
        if post.get('activate') == 'on':
            subscription.get_confirm_subscription()
        return request.redirect('/my/subscriptions')

    # Contracts

    @http.route(['/my/update_subscription_contract'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def subscription_contract_update(self, **post):
        subscription_contract = request.env['subscription.contract'].browse(
            int(post.get('subscription_contract_id')))
        values = {
            'name': post.get('name'),
            'partner_id': int(post.get('customer_id')),
            'pricelist_id': int(post.get('pricelist_id')),
            'contract_status': post.get('contract_status'),
            'reason': post.get('reason'),
            'latest_record': True if post.get(
                'latest_record') == 'on' else False,
            'contract_type': post.get('contract_type'),
            'allowed_freeze_count': int(post.get('allowed_freeze_count')),
            'freeze_price': float(post.get('freeze_price')),
            'freeze_period': int(post.get('freeze_period'))
        }
        subscription_contract.sudo().write(values)
        if post.get('signed_agreement'):
            subscription_contract.write({
                'signed_agreement': base64.b64encode(post.get(
                    'signed_agreement').read()),
            })
        return request.redirect(
            '/my/subscription_contract_details/%s' % subscription_contract.id)

    @http.route(['/my/subscription_contract_details/<int:contract_id>'],
                type='http',
                auth='user', website=True)
    def subscription_contract_details(self, **kwargs):
        subscription_contract = request.env[
            'subscription.contract'].sudo().browse(
            kwargs.get('contract_id'))
        print(subscription_contract.latest_record)
        values = {
            'is_account': True,
            'subscription_contract': subscription_contract,
            'customers': request.env['res.partner'].search([
                ('id', '!=', subscription_contract.partner_id.id)
            ]),
            'price_lists': request.env['product.pricelist'].search([
                ('id', '!=', subscription_contract.pricelist_id.id)
            ]),
        }
        return request.render(
            'sports_erp_dashboard.subscription_contract_edit_template', values)

    @http.route('/my/delete_subscription_contract/<int:subscription_contract>',
                type='http', auth='user', website=True
                )
    def delete_subscription_contract(self, **kwargs):
        print("kw", kwargs)
        subscription_contract = request.env[
            'subscription.contract'].sudo().browse(
            kwargs.get('subscription_contract'))
        subscription_contract.sudo().unlink()
        return request.redirect('/my/subscription_contracts')

    @http.route(['/create/subscription_contract'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def create_contract(self, **post):
        values = {
            'name': post.get('contract_name'),
            'partner_id': int(post.get('partner_id')),
            'pricelist_id': int(post.get('pricelist')),
            'contract_status': post.get('active'),
            'reason': post.get('reason'),
            'latest_record': True if post.get(
                'latest_record') == 'on' else False,
            'contract_type': post.get('contract_type'),
            'allowed_freeze_count': post.get('allowed_freeze_count'),
            'freeze_period': post.get('freeze_period'),
            'freeze_price': post.get('freeze_price'),
            'company_id': request.env.user.company_id.id,
            'organisation_ids': [(4, request.env[
                'organisation.organisation'].sudo().search(
                [('partner_id', '=', request.env.user.partner_id.id),
                 ('is_selected_organisation', '=', True), ], limit=1).id)]
        }
        subscription_contract = request.env[
            'subscription.contract'].sudo().create(
            values)
        if post.get('signed_agreement'):
            subscription_contract.sudo().write({
                'signed_agreement': base64.b64encode(post.get(
                    'signed_agreement').read())
            })
        return request.redirect('/my/subscription_contracts')

    @http.route(['/my/subscription_contracts'], type='http',
                auth='user', website=True)
    def contracts_home(self, page=0, search='', **post):
        domain = [('company_id', '=', request.env.user.company_id.id), ]
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        subscription_contract_all = request.env[
            'subscription.contract'].sudo().search(
            domain)
        subscription_contract = subscription_contract_all.filtered(
            lambda x: x.company_id.id == request.env.user.company_id.id)
        total = len(subscription_contract)
        pager = request.website.pager(
            url='/my/subscription_contracts',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        subscription_contract = subscription_contract[offset: offset + 6]
        values = {
            'search': search,
            'subscription_contract': subscription_contract,
            'pager': pager,
            'is_account': True,
            'total_subscription_contracts': request.env[
                'subscription.contract'].sudo().search(
                [('company_id', '=', request.env.user.company_id.id,
                  )])
        }
        return request.render(
            'sports_erp_dashboard.subscription_contract_template', values)

    # Subscription Products

    @http.route(['/my/subscription_products'], type='http',
                auth='user', website=True)
    def products_home(self, page=0, search='', **post):
        domain = [('company_id', '=', request.env.user.company_id.id), ]
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        subscription_products = request.env[
            'product.product'].sudo().search(
            domain)
        subscription_product = subscription_products.filtered(
            lambda r: r.activate_subscription
        )
        total = len(subscription_product)
        pager = request.website.pager(
            url='/my/subscription_products',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        subscription_product = subscription_product[offset: offset + 6]
        values = {
            'search': search,
            'subscription_product': subscription_product,
            'pager': pager,
            'is_account': True,
            'total_subscription_products': request.env[
                'product.product'].sudo().search(
                [('activate_subscription', '=', True)])
        }
        return request.render(
            'sports_erp_dashboard.subscription_product_template', values)

    @http.route('/my/delete_subscription_product/<int:subscription_product>',
                type='http', auth='public', csrf=False, website=True)
    def delete_subscription_product(self, **kwargs):
        subscription_product = request.env['product.product'].sudo().browse(
            kwargs.get('subscription_product'))
        subscription_product.sudo().unlink()
        return request.redirect('/my/subscription_products')

    @http.route(['/create/subscription_product'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def subscription_product(self, **post):
        values = {'name': post.get('product_name'),
                  'activate_subscription': True,
                  'detailed_type': 'service',
                  'subscription_plan_id': int(
                      post.get('subscription_plan_ids')),
                  'subscription_contract_id': post.get(
                      'subscription_contract_ids'),
                  'list_price': post.get('sale_price'),
                  'company_id': request.env.user.company_id.id
                  }
        subscription_product = request.env[
            'product.product'].sudo().create(
            values)
        if post.get('photo'):
            subscription_product.sudo().write({
                'image_1920': base64.b64encode(post.get(
                    'photo').read())
            })
        return request.redirect('/my/subscription_products')

    @http.route(['/my/subscription_product_details/<int:product_id>'],
                type='http', auth='public', csrf=False, website=True)
    def subscription_product_details(self, **kwargs):
        print("kwa", kwargs)
        subscription_product = request.env['product.product'].sudo().browse(
            kwargs.get('product_id'))
        values = {
            'subscription_product': subscription_product,
            'is_account': True,
            'subscription_plans': request.env['subscription.plan'].search([
                ('id', '!=', subscription_product.subscription_plan_id.id)
            ]),
            'subscription_contracts': request.env[
                'subscription.contract'].search([
                ('id', '!=', subscription_product.subscription_contract_id.id)
            ]),
        }
        print(subscription_product)
        response = request.render(
            "sports_erp_dashboard.subscription_product_details", values)
        return response

    @http.route(['/my/update_subscription_product'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_subscription_product(self, **post):
        product = request.env['product.product'].sudo().browse(
            int(post.get('subscription_product_id')))
        values = {
            'name': post.get('name'),
            'is_subscription_addon': True if post.get(
                'subscription_addon') == 'on' else False,
            'list_price': float(post.get('sale_price')),
            'subscription_plan_id': int(post.get('subscription_plan')),
            'subscription_contract_id': int(post.get('subscription_contract'))
        }
        product.sudo().write(values)
        if post.get('photo'):
            product.sudo().write({
                'image_1920': base64.b64encode(post.get(
                    'photo').read())
            })
        return request.redirect(
            '/my/subscription_product_details/%s' % product.id)

    # Subscription Plan

    @http.route(['/my/update_subscription_plan'], type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def update_subscription_plan(self, **post):
        plan = request.env[
            'subscription.plan'].browse(int(post.get('plan_id')))
        task_ids = list(
            map(int, request.httprequest.form.getlist('stage_ids')))
        values = {
            'name': post.get('name'),
            'duration': int(post.get('duration')),
            'unit': post.get('duration_type'),
            'never_expires': True if post.get(
                'never_expires') == 'on' else False,
            'num_billing_cycle': int(post.get('num_billing_cycles')),
            'start_immediately': True if post.get(
                'start_immediate') == 'on' else False,
            'month_billing_day': int(post.get('month_billing_day')),
            'plan_amount': float(post.get('price')),
            'trial_period': True if post.get(
                'has_trial') == 'on' else False,
            'trial_duration': int(post.get('trial_duration')),
            'trial_duration_unit': post.get('trial_duration_unit'),
            'sessions': int(post.get('sessions')),
            'one2one': int(post.get('one2one')),
            'project_template_id': int(
                post.get('responsible_user')) if post.get(
                'project_template_id') else None,
            'override_product_price': True if post.get(
                'override_product_price') == 'on' else False,
        }
        plan.sudo().write(values)
        plan.sudo().write({
            'stage_ids': [(5, 0, 0)],
        })
        if task_ids:
            plan.sudo().write({
                'stage_ids': [(4, task) for task in task_ids]
            })
        return request.redirect('/my/subscription_plan_details/%s' % plan.id)

    @http.route(['/my/subscription_plan_details/<int:plan_id>'], type='http',
                auth='user', website=True)
    def subscription_plan_details(self, **kwargs):
        print("kw", kwargs)
        plan = request.env['subscription.plan'].browse(kwargs.get('plan_id'))
        print(plan)
        values = {
            'plan': plan,
            'is_account': True,
            'templates': request.env['project.project'].search([
                ('id', '!=', plan.project_template_id.id),
                ('active', '=', True),
                ('is_template', '=', True)
            ]),
            'stages': request.env['project.task.type'].search([
                ('id', 'not in', plan.stage_ids.ids)
            ])
        }
        return request.render(
            'sports_erp_dashboard.subscription_plan_details_template', values)

    @http.route(['/my/subscription_plans'], type='http',
                auth='user', website=True)
    def subscription_plans_home(self, page=0, search='', **post):
        domain = [('company_id', '=', request.env.user.company_id.id), ]
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        subscriptions_plan_all = request.env['subscription.plan'].sudo().search(
            domain)
        subscription_plans = subscriptions_plan_all.filtered(lambda x:
                                                             x.organisation_ids.id == request.env.user.company_id.id)
        print('subscription_plans', subscription_plans)
        total = len(subscription_plans)
        pager = request.website.pager(
            url='/my/subscription_plans',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        subscription_plans = subscription_plans[offset: offset + 6]
        values = {
            'search': search,
            'subscription_plans': subscription_plans,
            'pager': pager,
            'is_account': True,
            'total_subscription_plans': request.env[
                'subscription.plan'].sudo().search(
                [('company_id', '=', request.env.user.company_id.id)])
        }
        print(values)
        return request.render(
            'sports_erp_dashboard.subscription_plan_template', values)

    @http.route('/my/delete_subscription_plan/<int:subscription_plan>',
                type='http', auth='public', csrf=False, website=True)
    def delete_subscription(self, **kwargs):
        print("kw", kwargs)
        subscription_plan = request.env['subscription.plan'].sudo().browse(
            kwargs.get('subscription_plan')
        )
        subscription_plan.sudo().unlink()
        return request.redirect('/my/subscription_plans')

    @http.route('/create/subscription_plan', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_subscription_plans(self, **post):
        task_ids = list(
            map(int, request.httprequest.form.getlist('task_stages')))
        values = {
            'name': post.get('plan_name'),
            'duration': int(post.get('duration')),
            'unit': post.get('duration_type'),
            'plan_amount': float(post.get('price')),
            'never_expires': True if post.get(
                'never_expires') == 'on' else False,
            'num_billing_cycle': int(post.get('billing_cycles')),
            'start_immediately': True if post.get(
                'start_immediate') == 'on' else False,
            'trial_period': True if post.get(
                'has_trial') == 'on' else False,
            'month_billing_day': int(post.get('billing_month_day')),
            'trial_duration': int(post.get('trial_duration')),
            'trial_duration_unit': post.get('trial_duration_type'),
            'sessions': int(post.get('no_of_sessions')),
            'one2one': int(post.get('one2one')),
            'stage_ids': [(4, task) for task in task_ids],
            'project_template_id': int(
                post.get('project_template_id')) if post.get(
                'project_template_id') else None,
            'override_product_price': True if post.get(
                'override_product_price') == 'on' else False,
            'company_id': request.env.user.company_id.id,
            'organisation_ids': [(4, request.env[
                'organisation.organisation'].sudo().search(
                [('partner_id', '=', request.env.user.partner_id.id),
                 ('is_selected_organisation', '=', True), ], limit=1).id)]
        }
        plan = request.env['subscription.plan'].create(values)
        return request.redirect('/my/subscription_plans')

    # Subscription Customers

    @http.route('/my/delete_subscription_customer/<int:subscription_customer>',
                type='http', auth='public', csrf=False, website=True)
    def subscription_customer(self, **kwargs):
        print('kw', kwargs)
        subscription_customer = request.env['res.partner'].sudo().browse(
            kwargs.get('subscription_customer')
        )
        print("sus", subscription_customer)
        subscription_customer.sudo().unlink()
        return request.redirect('/my/subscription_customers')

    @http.route(['/my/update_subscription_customer'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_subscription_customer(self, **post):
        print('pos', post)
        customer = request.env['res.partner'].sudo().browse(
            int(post.get('subscription_customer_id')))
        values = {
            'name': post.get('name'),
            'last_name': post.get('last_name'),
            'email': post.get('email'),
            'city': post.get('city'),
            'zip': post.get('zip_code'),
            'phone': post.get('phone'),
            'street': post.get('street_name'),
            'state_id': int(post.get('state')),
            'country_id': int(post.get('country')),
        }
        customer.sudo().write(values)
        if post.get('photo'):
            customer.sudo().write({
                'image_1920': base64.b64encode(post.get(
                    'photo').read())
            })
        return request.redirect(
            '/my/subscription_customer_details/%s' % customer.id)

    @http.route(['/my/subscription_customer_details/<int:customer_id>'],
                type='http',
                auth='user', website=True)
    def subscription_customer_details(self, **kwargs):
        print("kwa", kwargs)
        subscription_customer = request.env['res.partner'].sudo().browse(
            kwargs.get('customer_id')
        )
        values = {
            'subscription_customer': subscription_customer,
            'is_account': True,
            'countries': request.env[
                'res.country'].sudo().search([
                ('id', '!=', subscription_customer.country_id.id)
            ]),
            'states': request.env[
                'res.country.state'].sudo().search([
                ('id', '!=', subscription_customer.state_id.id)
            ])

        }
        return request.render(
            'sports_erp_dashboard.subscription_customer_details_template',
            values)

    @http.route(['/my/subscription_customers',
                 '/my/subscription_customers/page/<int:page>'],
                type='http',
                auth='user', website=True)
    def subscription_customers_home(self, page=0, search='', **post):
        domain = []
        if search:
            domain.append(('name', 'ilike', search))
            post["search"] = search
        subscription_customers = request.env['res.partner'].sudo().search(
            domain)
        total = len(subscription_customers)
        pager = request.website.pager(
            url='/my/subscription_customers',
            total=total,
            page=page,
            step=6,
        )
        offset = pager['offset']
        subscription_customers = subscription_customers[offset: offset + 6]
        print("sus", subscription_customers)
        values = {
            'search': search,
            'subscription_customers': subscription_customers,
            'pager': pager,
            'is_account': True,
            'total_subscription_customers': request.env[
                'res.partner'].sudo().search(
                [])
        }
        print("values", values)
        return request.render(
            'sports_erp_dashboard.subscription_customer_template', values)

    @http.route('/create/subscription_customer', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_customer(self, **post):
        print("pos", post)
        values = {
            'name': post.get('customer_name'),
            'last_name': post.get('last_name'),
            'phone': post.get('phone'),
            'email': post.get('email'),
            'street': post.get('street_name'),
            'city': post.get('city_name'),
            'state_id': int(post.get('state_id')),
            'zip': post.get('zip_code'),
            'country_id': int(post.get('country_id'))
        }
        customer = request.env['res.partner'].sudo().create(values)
        if post.get('photo'):
            customer.sudo().write({
                'image_1920': base64.b64encode(post.get(
                    'photo').read())
            })
        return request.redirect('/my/subscription_customers')

    # Chathub
    @http.route('/create/chathub', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def create_chathub(self, **post):
        print(post, "posttttt")
        if post:
            member_ids = list(
                map(int, request.httprequest.form.getlist('members')))
            values = {
                'name': post.get('name'),
                'partner_ids': [(4, member) for member in member_ids],
                'description': post.get('description')
            }
            request.env['chat.hub'].sudo().create(values)
            return request.redirect('/my/home')

    @http.route('/edit/chathubs', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def edit_chathub(self, **post):
        chat_hubs = request.env['chat.hub'].sudo().search([])
        return request.render('sports_erp_dashboard.chat_hub_template',
                              {'is_account': True, 'chat_hubs': chat_hubs})

    @http.route('/my/chat_hub_details/<model("chat.hub"):chathub_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def chathub_details(self, chathub_id=None):
        print("chathub", chathub_id.partner_ids)

        return request.render('sports_erp_dashboard.chathub_details_template',
                              {'is_account': True,
                               'chathub': chathub_id,
                               # 'res_users': request.env[
                               #     'res.users'].sudo().search([]),
                               # 'tags': request.env['fans.tags'].sudo().search(
                               #     [('id', 'not in', fan.tag_ids.ids)]),
                               # 'organisations': request.env[
                               #     'organisation.organisation'].sudo().search(
                               #     [('id', '!=', fan.organisation_id.id)]),
                               })

    @http.route('/my/delete_chat_hub/<model("chat.hub"):chathub_id>',
                type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def remove_chathub(self, chathub_id=None):
        if chathub_id:
            chathub_id.sudo().unlink()
        return request.redirect('/edit/chathubs')

    @http.route(['/my/update_chathub'], type='http',
                auth='public', csrf=False, website=True,
                methods=['POST', 'GET'])
    def update_chathub(self, **post):
        print("post", post)
        chathub = request.env[
            'chat.hub'].sudo().browse(int(post.get('chathub_id')))
        chathub.sudo().write({
            'name': post.get('name'),
            'description': post.get('description'),
        })
        # chathub.sudo().write({
        #     'partner_ids': [(5, 0, 0)],
        # })
        member_ids = list(
            map(int, request.httprequest.form.getlist('members')))
        print(member_ids)
        chathub.sudo().write({
            'partner_ids': [(4, member) for member in member_ids]
        })
        return request.redirect('/my/chat_hub_details/%s' % chathub.id)

    @http.route('/my/profile', type='http',
                auth='public', csrf=False, website=True,
                method='POST')
    def my_profile(self, **post):
        organisation = request.env['organisation.organisation'].sudo().search(
            [('allowed_user_ids', 'in', [request.env.user.id]),
             ('id', '=',
              request.httprequest.cookies.get('selected_organisation'))],
            limit=1)
        print(request.httprequest.cookies.get('selected_organisation'), "organisation")
        return request.render('sports_erp_dashboard.my_profile_template', {'organisation': organisation, 'is_account': True})

