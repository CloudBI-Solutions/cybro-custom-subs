odoo.define('sports_erp_dashboard.coach', function (require) {
    "use strict";
    const dom = require('web.dom');
    var publicWidget = require('web.public.widget');
    var PortalSidebar = require('portal.PortalSidebar');
    var utils = require('web.utils');
    var rpc = require('web.rpc');

    $(document).ready(function () {
      $('.sports-erp-dashbaord-select').select2();
    });

    publicWidget.registry.CoachPage = publicWidget.Widget.extend({
        selector: '.js_usermenu',
        events: {
            'change #organisations': '_onChangeOrganisation',
        },

        _onChangeOrganisation: function (ev) {
            console.log("event")
        },
        start() {
            const def = this._super(...arguments);
            console.log(this.cookie, "def")
            this.cookie.setCookie("selected_organisation", false);
            return def;
        },
        /**
         * @override
         */

    });
});