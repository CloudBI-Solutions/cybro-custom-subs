var MenuToggle = $("#se-menu-toggle");
MenuToggle.click(function(e){
   e.preventDefault();
   console.log("Menu",$('.se-sidebar'))
   $('.se-sidebar').toggleClass('se-sidebar--show')
})