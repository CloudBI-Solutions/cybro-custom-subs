## Module <odoo11_magento2>

#### 04.07.2021
#### Version 14.0.1.0.0
##### ADD

- Initial Commit for odoo11_magento2

#### 04.06.2022
#### Version 14.0.1.1.1
##### UPDATE

- Added dashboard functionality for odoo11_magento2
- Connected the shipment in magento with magento sale order
- Minor bug fixes - adding name to website, store and shipment forms
