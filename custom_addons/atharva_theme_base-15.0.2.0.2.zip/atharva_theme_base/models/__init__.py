# -*- coding: utf-8 -*-

from . import product_extra_info
from . import product_label
from . import product_tags
from . import product_template
from . import product_brand
from . import product_tabs
from . import pwa
from . import faqs
from . import website
from . import pricelist
